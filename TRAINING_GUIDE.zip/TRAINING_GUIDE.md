# Quick Start Guide - Retraining with Fixed Code

## Prerequisites

```powershell
# Install required dependencies
pip install einops>=0.6.0
```

## Training Commands

### 1. Writer-Independent Signature Verification

#### Bengali Dataset (50 writers training)
```powershell
python -m sigverify.train.train_verification `
    --root data/BHSig260-Bengali/BHSig260-Bengali `
    --train_writers 50 `
    --batch 64 `
    --epochs 30 `
    --lr 1e-4 `
    --margin 1.0 `
    --out checkpoints/bengali_verification.pt `
    --val_every 5
```

#### Hindi Dataset (100 writers training)
```powershell
python -m sigverify.train.train_verification `
    --root data/BHSig260-Hindi/BHSig260-Hindi `
    --train_writers 100 `
    --batch 64 `
    --epochs 30 `
    --lr 1e-4 `
    --margin 1.0 `
    --out checkpoints/hindi_verification.pt `
    --val_every 5
```

#### Multi-Dataset Training (Bengali + Hindi)
```powershell
python -m sigverify.train.train_verification `
    --roots "bengali=data/BHSig260-Bengali/BHSig260-Bengali,hindi=data/BHSig260-Hindi/BHSig260-Hindi" `
    --train_writers_map "bengali=50,hindi=100" `
    --batch 64 `
    --epochs 30 `
    --lr 1e-4 `
    --out checkpoints/multi_verification.pt `
    --val_every 5
```

### 2. Signature Recognition (Writer Identification)

#### CEDAR Dataset (25% training samples)
```powershell
python -m sigverify.train.train_recognition `
    --root data/CEDAR/CEDAR `
    --train_pct 0.25 `
    --batch 32 `
    --epochs 50 `
    --lr 1e-2 `
    --out checkpoints/cedar_recognition_25.pt
```

#### CEDAR Dataset (50% training samples)
```powershell
python -m sigverify.train.train_recognition `
    --root data/CEDAR/CEDAR `
    --train_pct 0.50 `
    --batch 32 `
    --epochs 50 `
    --lr 1e-2 `
    --out checkpoints/cedar_recognition_50.pt
```

#### MCYT Dataset (25% training samples)
```powershell
python -m sigverify.train.train_recognition `
    --root data/MCYT/MCYT `
    --train_pct 0.25 `
    --batch 32 `
    --epochs 50 `
    --lr 1e-2 `
    --out checkpoints/mcyt_recognition_25.pt
```

## Inference

### Verify a Single Signature Pair

```powershell
python -m sigverify.infer_verify `
    --ckpt checkpoints/bengali_verification.pt `
    --ref path/to/reference_signature.png `
    --query path/to/query_signature.png `
    --thr 0.45
```

**Note**: Use the "Adaptive Thr" value printed during training validation for the `--thr` parameter.

## Expected Training Behavior

### ✅ Correct Training (After Fixes)
- Loss **decreases** over epochs
- Training accuracy **increases**
- Validation accuracy improves
- EER on training set: ~5-7% (Bengali/Hindi)

### ❌ Incorrect Training (Before Fixes)
- Loss might increase or not converge
- Model pushes genuine pairs apart
- Pulls forgery pairs together
- Very poor verification performance

## Monitoring Training

Key metrics to watch:

1. **Training Loss**: Should steadily decrease
   - Epoch 0: ~0.5-0.8
   - Epoch 10: ~0.2-0.4
   - Epoch 30: ~0.1-0.2

2. **Validation Metrics** (printed every `--val_every` epochs):
   - ACC (Adaptive): Should reach 90%+ by epoch 20-30
   - FRR/FAR: Should balance around 5-10%
   - EER: Should be < 10%

3. **Early Stopping**: Training stops if loss doesn't improve for 10 epochs

## Troubleshooting

### Issue: Loss increases or doesn't decrease
**Solution**: Verify contrastive loss formula is correct (should be `α(1-y)D² + βy max(0, m-D)²`)

### Issue: Out of memory
**Solution**: Reduce `--batch` size (try 32 or 16)

### Issue: Training too slow
**Solution**: 
- Reduce `--val_every` (validate less frequently)
- Use `--val_max_pairs 1000` (limit validation pairs)

### Issue: ImportError for einops
**Solution**: `pip install einops>=0.6.0`

## Hardware Requirements

- **GPU**: Recommended (NVIDIA RTX 3090 or similar)
- **RAM**: 16GB+ recommended
- **Storage**: ~5GB for datasets + checkpoints

## Training Time Estimates

| Dataset | Training Samples | Epochs | Time (RTX 3090) |
|---------|-----------------|--------|-----------------|
| Bengali | 50 writers | 30 | ~2-3 hours |
| Hindi | 100 writers | 30 | ~4-5 hours |
| CEDAR (25%) | 6 per writer | 50 | ~1-2 hours |
| MCYT (25%) | 4 per writer | 50 | ~1-2 hours |

## Post-Training

After training completes:

1. Check the final validation metrics in terminal output
2. Note the "Adaptive Thr" value for inference
3. Test with `infer_verify.py` on held-out test pairs
4. Compare results with paper benchmarks (see CODE_REVIEW_FIXES.md)

## Paper Benchmark Targets

### Recognition (CEDAR, 25% training):
- Target: **98.85%** accuracy

### Verification (Bengali):
- Adaptive: ACC **92.87%**, FRR 11.29%, FAR 2.97%
- Max: ACC **95.12%**, FRR 4.52%, FAR 5.34%

### Verification (Hindi):
- Adaptive: ACC **92.24%**, FRR 4.43%, FAR 11.09%
- Max: ACC **92.33%**, FRR 4.61%, FAR 8.12%

---

**Note**: Results may vary slightly due to random initialization and data shuffling. Run multiple times and report average for paper comparison.
