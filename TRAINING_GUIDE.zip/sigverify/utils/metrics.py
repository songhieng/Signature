from typing import Tuple, Dict
import numpy as np


def compute_far_frr(distances: np.ndarray, labels: np.ndarray, threshold: float) -> Tuple[float, float]:
    """Compute FAR, FRR for given threshold.

    labels: 1 for genuine (same writer), 0 for forgery (different writer).
    distances: Euclidean distance (smaller means similar).
    """
    assert distances.shape == labels.shape
    genuine = labels == 1
    forgery = ~genuine

    false_rejects = np.sum((distances[genuine] > threshold))
    false_accepts = np.sum((distances[forgery] <= threshold))

    frr = false_rejects / genuine.sum() if genuine.sum() else 0.0
    far = false_accepts / forgery.sum() if forgery.sum() else 0.0
    return far, frr


def confusion_counts(distances: np.ndarray, labels: np.ndarray, threshold: float):
    """Return TP, TN, FP, FN at the given threshold.

    labels: 1 for genuine (similar), 0 for forgery (dissimilar)
    decision: genuine if distance <= threshold
    """
    genuine = labels == 1
    forgery = ~genuine

    tp = int(np.sum((distances[genuine] <= threshold)))
    fn = int(np.sum((distances[genuine] > threshold)))
    fp = int(np.sum((distances[forgery] <= threshold)))
    tn = int(np.sum((distances[forgery] > threshold)))
    return tp, tn, fp, fn


def compute_acc(distances: np.ndarray, labels: np.ndarray, threshold: float) -> float:
    tp, tn, fp, fn = confusion_counts(distances, labels, threshold)
    denom = tp + tn + fp + fn
    return (tp + tn) / denom if denom else 0.0


def find_adaptive_threshold(distances: np.ndarray, labels: np.ndarray, step: float = 0.01):
    """Search threshold that minimises |FAR-FRR| on the given set.

    Returns (best_threshold, eer_at_best_threshold).
    """
    mn, mx = float(distances.min()), float(distances.max())
    best_thr = mn
    best_gap = float('inf')
    best_eer = 1.0

    thr = mn
    while thr <= mx:
        far, frr = compute_far_frr(distances, labels, thr)
        gap = abs(far - frr)
        eer = (far + frr) / 2.0
        if gap < best_gap:
            best_gap = gap
            best_thr = thr
            best_eer = eer
        thr += step

    return best_thr, best_eer


def find_max_acc_threshold(distances: np.ndarray, labels: np.ndarray, step: float = 0.01):
    """Search threshold that maximises ACC on the given set."""
    mn, mx = float(distances.min()), float(distances.max())
    best_thr = mn
    best_acc = -1.0

    thr = mn
    while thr <= mx:
        acc = compute_acc(distances, labels, thr)
        if acc > best_acc:
            best_acc = acc
            best_thr = thr
        thr += step

    return best_thr, best_acc


def find_percentile_threshold(
    genuine_distances: np.ndarray,
    forgery_distances: np.ndarray,
    percentile: float = 95.0,
) -> float:
    """Find threshold using percentile of genuine distances.
    
    Sets threshold at the p-th percentile of genuine pair distances.
    This ensures that p% of genuine pairs will be accepted.
    
    Args:
        genuine_distances: Distances between genuine pairs
        forgery_distances: Distances between forgery pairs
        percentile: Percentile of genuine distances to use (default 95)
    
    Returns:
        Threshold value
    """
    return np.percentile(genuine_distances, percentile)


def find_roc_optimal_threshold(
    distances: np.ndarray,
    labels: np.ndarray,
    step: float = 0.005,
) -> Tuple[float, Dict]:
    """Find optimal threshold using ROC analysis.
    
    Finds threshold that maximizes Youden's J statistic (TPR - FPR),
    which is equivalent to maximizing balanced accuracy.
    
    Returns:
        (threshold, metrics_dict)
    """
    genuine = labels == 1
    forgery = ~genuine
    
    gen_dist = distances[genuine]
    forg_dist = distances[forgery]
    
    mn = float(min(distances.min(), 0))
    mx = float(distances.max())
    
    best_thr = (mn + mx) / 2
    best_j = -1.0
    best_metrics = {}
    
    thr = mn
    while thr <= mx:
        # TPR = 1 - FRR (proportion of genuine correctly accepted)
        tpr = np.mean(gen_dist <= thr) if len(gen_dist) > 0 else 0.0
        # FPR = FAR (proportion of forgery incorrectly accepted)
        fpr = np.mean(forg_dist <= thr) if len(forg_dist) > 0 else 0.0
        
        # Youden's J = TPR - FPR = sensitivity + specificity - 1
        j = tpr - fpr
        
        if j > best_j:
            best_j = j
            best_thr = thr
            best_metrics = {
                'tpr': tpr,
                'fpr': fpr,
                'fnr': 1 - tpr,  # FRR
                'tnr': 1 - fpr,  # specificity
                'j_statistic': j,
                'balanced_acc': (tpr + (1 - fpr)) / 2,
            }
        thr += step
    
    return best_thr, best_metrics


def find_cross_validated_threshold(
    distances: np.ndarray,
    labels: np.ndarray,
    n_folds: int = 5,
    step: float = 0.01,
) -> Tuple[float, float]:
    """Cross-validated threshold selection.
    
    Splits data into folds, finds EER threshold on each fold,
    and returns the average threshold.
    
    Returns:
        (threshold, std_dev)
    """
    n = len(distances)
    indices = np.arange(n)
    np.random.shuffle(indices)
    fold_size = n // n_folds
    
    thresholds = []
    
    for i in range(n_folds):
        # Split into train/val for this fold
        val_start = i * fold_size
        val_end = (i + 1) * fold_size if i < n_folds - 1 else n
        val_idx = indices[val_start:val_end]
        train_idx = np.concatenate([indices[:val_start], indices[val_end:]])
        
        train_dist = distances[train_idx]
        train_labels = labels[train_idx]
        
        # Find threshold on this fold
        thr, _ = find_adaptive_threshold(train_dist, train_labels, step)
        thresholds.append(thr)
    
    return np.mean(thresholds), np.std(thresholds)


def get_distance_statistics(
    distances: np.ndarray,
    labels: np.ndarray,
) -> Dict:
    """Compute statistics of distance distributions for diagnostics.
    
    Returns dict with mean, std, median, percentiles for both genuine and forgery.
    """
    genuine = labels == 1
    forgery = ~genuine
    
    gen_dist = distances[genuine]
    forg_dist = distances[forgery]
    
    stats = {
        'genuine': {
            'count': len(gen_dist),
            'mean': float(np.mean(gen_dist)) if len(gen_dist) > 0 else 0,
            'std': float(np.std(gen_dist)) if len(gen_dist) > 0 else 0,
            'median': float(np.median(gen_dist)) if len(gen_dist) > 0 else 0,
            'min': float(np.min(gen_dist)) if len(gen_dist) > 0 else 0,
            'max': float(np.max(gen_dist)) if len(gen_dist) > 0 else 0,
            'p25': float(np.percentile(gen_dist, 25)) if len(gen_dist) > 0 else 0,
            'p75': float(np.percentile(gen_dist, 75)) if len(gen_dist) > 0 else 0,
            'p95': float(np.percentile(gen_dist, 95)) if len(gen_dist) > 0 else 0,
        },
        'forgery': {
            'count': len(forg_dist),
            'mean': float(np.mean(forg_dist)) if len(forg_dist) > 0 else 0,
            'std': float(np.std(forg_dist)) if len(forg_dist) > 0 else 0,
            'median': float(np.median(forg_dist)) if len(forg_dist) > 0 else 0,
            'min': float(np.min(forg_dist)) if len(forg_dist) > 0 else 0,
            'max': float(np.max(forg_dist)) if len(forg_dist) > 0 else 0,
            'p25': float(np.percentile(forg_dist, 25)) if len(forg_dist) > 0 else 0,
            'p75': float(np.percentile(forg_dist, 75)) if len(forg_dist) > 0 else 0,
            'p95': float(np.percentile(forg_dist, 95)) if len(forg_dist) > 0 else 0,
        },
    }
    
    # Separation metrics
    if len(gen_dist) > 0 and len(forg_dist) > 0:
        # Fisher's criterion (ratio of between-class to within-class variance)
        mean_diff = abs(stats['genuine']['mean'] - stats['forgery']['mean'])
        pooled_std = np.sqrt((stats['genuine']['std']**2 + stats['forgery']['std']**2) / 2)
        stats['fisher_ratio'] = mean_diff / pooled_std if pooled_std > 0 else 0
        
        # Overlap: percentage of forgery distances less than median genuine
        stats['overlap'] = float(np.mean(forg_dist <= stats['genuine']['median']))
        
        # Separability index: 1 - overlap of distributions
        # Estimate using percentile comparison
        gen_p90 = np.percentile(gen_dist, 90)
        forg_below_gen90 = np.mean(forg_dist <= gen_p90)
        stats['separability'] = 1.0 - forg_below_gen90
    else:
        stats['fisher_ratio'] = 0
        stats['overlap'] = 1.0
        stats['separability'] = 0
    
    return stats


def print_distance_stats(stats: Dict, tag: str = ""):
    """Pretty print distance statistics."""
    prefix = f"[{tag}] " if tag else ""
    
    g = stats['genuine']
    f = stats['forgery']
    
    print(f"\n{prefix}Distance Distribution Statistics:")
    print(f"  Genuine  (n={g['count']:4d}): mean={g['mean']:.3f} std={g['std']:.3f} "
          f"[{g['min']:.3f}, {g['p25']:.3f}, {g['median']:.3f}, {g['p75']:.3f}, {g['max']:.3f}]")
    print(f"  Forgery  (n={f['count']:4d}): mean={f['mean']:.3f} std={f['std']:.3f} "
          f"[{f['min']:.3f}, {f['p25']:.3f}, {f['median']:.3f}, {f['p75']:.3f}, {f['max']:.3f}]")
    print(f"  Fisher ratio: {stats['fisher_ratio']:.3f}  Overlap: {stats['overlap']:.1%}  "
          f"Separability: {stats['separability']:.1%}")
