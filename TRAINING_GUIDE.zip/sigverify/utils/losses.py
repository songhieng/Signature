import torch
import torch.nn as nn
import torch.nn.functional as F


class ContrastiveLoss(nn.Module):
    """Improved contrastive loss with margin for Siamese networks.
    
    Standard formulation:
    - label=1 for genuine (same writer) -> should minimize distance
    - label=0 for forgery (different writer) -> should maximize distance
    
    Loss = label * D² + (1-label) * max(0, m-D)²
    
    Improvements:
    - Soft margin option for smoother gradients
    - Weighted loss for imbalanced classes
    - Margin scheduling support
    
    Args:
        margin: The margin m for dissimilar pairs. Default 1.0.
        pos_weight: Weight for genuine pairs (increase if FRR too high)
        neg_weight: Weight for forgery pairs (increase if FAR too high)
        soft_margin: If True, use log-sum-exp instead of hard ReLU
    """

    def __init__(
        self, 
        margin: float = 1.0,
        pos_weight: float = 1.0,
        neg_weight: float = 1.0,
        soft_margin: bool = False,
    ):
        super().__init__()
        self.margin = margin
        self.pos_weight = pos_weight
        self.neg_weight = neg_weight
        self.soft_margin = soft_margin

    def forward(self, dist: torch.Tensor, label: torch.Tensor):
        """
        Args:
            dist: (B,) Euclidean distances between feature pairs
            label: (B,) float labels, 1.0 for genuine, 0.0 for forgery
        
        Returns:
            Scalar loss value
        """
        # Genuine: minimize distance
        pos_loss = label * dist.pow(2) * self.pos_weight
        
        # Forgery: maximize distance beyond margin
        if self.soft_margin:
            # Soft margin: log(1 + exp(margin - dist))
            neg_loss = (1 - label) * F.softplus(self.margin - dist).pow(2) * self.neg_weight
        else:
            neg_loss = (1 - label) * torch.relu(self.margin - dist).pow(2) * self.neg_weight
        
        loss = pos_loss + neg_loss
        return loss.mean()


class TripletLoss(nn.Module):
    """Triplet loss for metric learning.
    
    For each anchor, we want: d(anchor, positive) + margin < d(anchor, negative)
    
    Args:
        margin: Margin between positive and negative distances
        mining: 'none', 'hard', 'semi-hard', 'all'
    """
    
    def __init__(self, margin: float = 0.5, mining: str = 'hard'):
        super().__init__()
        self.margin = margin
        self.mining = mining
    
    def forward(self, embeddings: torch.Tensor, labels: torch.Tensor):
        """
        Args:
            embeddings: (B, D) normalized embeddings
            labels: (B,) writer labels for mining
        
        Returns:
            Scalar triplet loss
        """
        # Compute pairwise distances
        dist_mat = torch.cdist(embeddings, embeddings, p=2)  # (B, B)
        
        batch_size = embeddings.size(0)
        
        # Create masks for positive and negative pairs
        labels_eq = labels.unsqueeze(0) == labels.unsqueeze(1)  # (B, B)
        labels_ne = ~labels_eq
        
        # Mask out diagonal
        eye = torch.eye(batch_size, device=embeddings.device, dtype=torch.bool)
        pos_mask = labels_eq & ~eye
        neg_mask = labels_ne
        
        losses = []
        
        for i in range(batch_size):
            pos_indices = pos_mask[i].nonzero(as_tuple=True)[0]
            neg_indices = neg_mask[i].nonzero(as_tuple=True)[0]
            
            if len(pos_indices) == 0 or len(neg_indices) == 0:
                continue
            
            pos_dists = dist_mat[i, pos_indices]
            neg_dists = dist_mat[i, neg_indices]
            
            if self.mining == 'hard':
                # Hardest positive: furthest positive
                hardest_pos = pos_dists.max()
                # Hardest negative: closest negative
                hardest_neg = neg_dists.min()
                loss = F.relu(hardest_pos - hardest_neg + self.margin)
            elif self.mining == 'semi-hard':
                # For each positive, find semi-hard negatives
                # Semi-hard: negative further than positive but within margin
                for pd in pos_dists:
                    valid_negs = neg_dists[(neg_dists > pd) & (neg_dists < pd + self.margin)]
                    if len(valid_negs) > 0:
                        losses.append(F.relu(pd - valid_negs.min() + self.margin))
                continue
            else:  # 'all' or 'none'
                # All triplets
                for pd in pos_dists:
                    for nd in neg_dists:
                        losses.append(F.relu(pd - nd + self.margin))
                continue
            
            losses.append(loss)
        
        if len(losses) == 0:
            return torch.tensor(0.0, device=embeddings.device, requires_grad=True)
        
        return torch.stack(losses).mean()


class CombinedVerificationLoss(nn.Module):
    """Combined loss for signature verification.
    
    Combines contrastive loss with optional triplet loss and center loss.
    
    Args:
        margin_contrastive: Margin for contrastive loss
        margin_triplet: Margin for triplet loss
        triplet_weight: Weight for triplet loss (0 to disable)
        pos_weight: Weight for genuine pairs in contrastive loss
    """
    
    def __init__(
        self,
        margin_contrastive: float = 1.0,
        margin_triplet: float = 0.5,
        triplet_weight: float = 0.0,
        pos_weight: float = 1.5,
    ):
        super().__init__()
        self.contrastive = ContrastiveLoss(
            margin=margin_contrastive,
            pos_weight=pos_weight,
            neg_weight=1.0,
            soft_margin=True,
        )
        self.triplet_weight = triplet_weight
        if triplet_weight > 0:
            self.triplet = TripletLoss(margin=margin_triplet, mining='hard')
    
    def forward(
        self,
        dist: torch.Tensor,
        label: torch.Tensor,
        embeddings: torch.Tensor = None,
        writer_labels: torch.Tensor = None,
    ):
        """
        Args:
            dist: (B,) pairwise distances
            label: (B,) 1=genuine, 0=forgery
            embeddings: (B, D) optional for triplet loss
            writer_labels: (B,) optional writer IDs for triplet mining
        """
        loss = self.contrastive(dist, label)
        
        if self.triplet_weight > 0 and embeddings is not None and writer_labels is not None:
            triplet_loss = self.triplet(embeddings, writer_labels)
            loss = loss + self.triplet_weight * triplet_loss
        
        return loss
