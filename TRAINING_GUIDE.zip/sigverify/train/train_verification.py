#!/usr/bin/env python
"""Writer-independent offline signature verification with optional multi-dataset training.

This script supports:

1) Single dataset:
   python -m sigverify.train.train_verification --root data/BHSig260-Bengali/BHSig260-Bengali --train_writers 50

2) Multiple datasets combined for training + per-dataset evaluation splits:
   python -m sigverify.train.train_verification \
     --roots "bengali=data/BHSig260-Bengali/BHSig260-Bengali,hindi=data/BHSig260-Hindi/BHSig260-Hindi,cedar=data/CEDAR/CEDAR" \
     --train_writers_map "bengali=50,hindi=100,cedar=30"

Validation control:
- Use --val_every N to validate every N epochs.
- Use --val_max_pairs to limit the number of pairs used for train/test during validation (per dataset).

Notes:
- Training uses on-the-fly random pairs across all roots.
- Evaluation is reported per dataset key. For each dataset, adaptive threshold is computed
  on that dataset's training writers and evaluated on that dataset's test writers.
- "Ours (Max)" is computed by selecting the threshold on the test set that maximizes ACC.

IMPORTANT (replication):
- Pair generation must correctly separate genuine/forgery per dataset. This implementation
  supports BHSig and CEDAR naming. (MCYT not included in this repo.)
"""

import argparse
import glob
import os
import random
from itertools import combinations
from typing import Dict, List, Tuple

import numpy as np
import torch
from torch.utils.data import DataLoader, Dataset
from tqdm import tqdm

from sigverify.datasets.common import DEFAULT_TRANSFORM
from sigverify.datasets.preprocess import preprocess_signature
from sigverify.models.hybrid_encoder import HybridEncoder
from sigverify.utils.losses import ContrastiveLoss
from sigverify.utils.metrics import (
    compute_acc,
    compute_far_frr,
    find_adaptive_threshold,
    find_max_acc_threshold,
)


def list_writer_dirs(root: str) -> List[str]:
    return sorted([d for d in os.listdir(root) if os.path.isdir(os.path.join(root, d))])


def _is_bhsig_file(name: str) -> bool:
    # Typical BHSig260: B-S-1-G-01.tif / B-S-1-F-01.tif / H-S-...
    return ('-G-' in name) or ('-F-' in name)


def build_fixed_pairs(writer_dir: str, max_pairs_per_class: int = 276) -> List[Tuple[str, str, int]]:
    """Dataset-aware pair generation.

    BHSig:
      - Genuine if filename contains '-G-'
      - Forgery if filename contains '-F-'
      - Uses all C(24,2)=276 GG pairs (if >=24 genuine)
      - Samples up to 276 GF pairs

    CEDAR:
      - Genuine if filename starts with 'original_'
      - Forgery if filename starts with 'forgeries_'
      - Samples up to max_pairs_per_class for GG and GF
    """
    imgs = sorted(glob.glob(os.path.join(writer_dir, '*')))
    if len(imgs) == 0:
        return []

    base_names = [os.path.basename(p) for p in imgs]

    # BHSig naming
    if any(_is_bhsig_file(n) for n in base_names):
        genuines = [p for p in imgs if '-G-' in os.path.basename(p)]
        forgeries = [p for p in imgs if '-F-' in os.path.basename(p)]

        # Paper protocol expects 24 genuine and 30 forgeries; enforce if possible
        genuines = genuines[:24] if len(genuines) >= 24 else genuines
        forgeries = forgeries[:30] if len(forgeries) >= 30 else forgeries

        pairs: List[Tuple[str, str, int]] = []

        # GG: all combinations if we have at least 2 genuines; cap to 276 (paper)
        gg_pairs = list(combinations(genuines, 2))
        # If more than 276 (shouldn't happen if 24 genuines), sample to 276
        if len(gg_pairs) > max_pairs_per_class:
            gg_pairs = random.sample(gg_pairs, max_pairs_per_class)
        pairs.extend([(a, b, 1) for a, b in gg_pairs])

        # GF: sample up to 276, balanced with GG count
        if len(forgeries) > 0 and len(genuines) > 0:
            target = min(max_pairs_per_class, len(gg_pairs) if len(gg_pairs) > 0 else max_pairs_per_class)
            gf_pairs = []
            for _ in range(target):
                gf_pairs.append((random.choice(genuines), random.choice(forgeries)))
            pairs.extend([(a, b, 0) for a, b in gf_pairs])

        return pairs

    # CEDAR naming
    lower_names = [n.lower() for n in base_names]
    if any(n.startswith('original_') or n.startswith('forgeries_') for n in lower_names):
        genuines = [p for p in imgs if os.path.basename(p).lower().startswith('original_')]
        forgeries = [p for p in imgs if os.path.basename(p).lower().startswith('forgeries_')]

        pairs: List[Tuple[str, str, int]] = []
        gg_pairs = list(combinations(genuines, 2))
        random.shuffle(gg_pairs)
        gg_pairs = gg_pairs[:max_pairs_per_class]
        pairs.extend([(a, b, 1) for a, b in gg_pairs])

        if len(forgeries) > 0 and len(genuines) > 0:
            target = min(max_pairs_per_class, len(gg_pairs) if len(gg_pairs) > 0 else max_pairs_per_class)
            gf_pairs = [(random.choice(genuines), random.choice(forgeries)) for _ in range(target)]
            pairs.extend([(a, b, 0) for a, b in gf_pairs])
        return pairs

    # Fallback (should not be used for your datasets)
    genuines = imgs[: len(imgs) // 2]
    forgeries = imgs[len(imgs) // 2 :]

    pairs: List[Tuple[str, str, int]] = []
    gg_pairs = list(combinations(genuines, 2))
    random.shuffle(gg_pairs)
    gg_pairs = gg_pairs[:max_pairs_per_class]
    pairs.extend([(a, b, 1) for a, b in gg_pairs])

    if len(forgeries) > 0 and len(genuines) > 0:
        target = min(max_pairs_per_class, len(gg_pairs) if len(gg_pairs) > 0 else max_pairs_per_class)
        gf_pairs = [(random.choice(genuines), random.choice(forgeries)) for _ in range(target)]
        pairs.extend([(a, b, 0) for a, b in gf_pairs])
    return pairs


class CombinedRandomPairDataset(Dataset):
    """On-the-fly random pairs across multiple datasets.

    IMPORTANT for replication:
    - For datasets that include skilled forgeries inside the writer folder (BHSig/CEDAR),
      "same-writer" does NOT imply "genuine".

    This dataset samples:
    - Positives (label=1): (G, G) from the same writer.
    - Negatives (label=0): (G, F) from the same writer if forgeries exist,
      otherwise (different-writer, different-writer).

    Also IMPORTANT:
    - Avoid writer leakage: only load training writers (per dataset split).
    """

    def __init__(
        self,
        key_to_root: Dict[str, str],
        train_writers_map: Dict[str, int] | None,
        default_train_writers: int,
    ):
        self.transform = DEFAULT_TRANSFORM

        # Each writer entry is a dict with keys:
        # - genuines: List[str]
        # - forgeries: List[str]
        # - all: List[str]
        self.writers: List[Dict[str, List[str]]] = []

        for key, root in key_to_root.items():
            writers = list_writer_dirs(root)
            limit = train_writers_map.get(key, default_train_writers) if train_writers_map else default_train_writers
            writers = writers[:limit]

            for w in writers:
                wdir = os.path.join(root, w)
                imgs = sorted(glob.glob(os.path.join(wdir, '*')))
                if len(imgs) < 2:
                    continue

                base_names = [os.path.basename(p) for p in imgs]

                # BHSig
                if any(_is_bhsig_file(n) for n in base_names):
                    genuines = [p for p in imgs if '-G-' in os.path.basename(p)]
                    forgeries = [p for p in imgs if '-F-' in os.path.basename(p)]
                else:
                    lower_names = [n.lower() for n in base_names]
                    # CEDAR
                    if any(n.startswith('original_') or n.startswith('forgeries_') for n in lower_names):
                        genuines = [p for p in imgs if os.path.basename(p).lower().startswith('original_')]
                        forgeries = [p for p in imgs if os.path.basename(p).lower().startswith('forgeries_')]
                    else:
                        genuines = imgs
                        forgeries = []

                if len(genuines) < 2:
                    continue

                self.writers.append({'genuines': genuines, 'forgeries': forgeries, 'all': imgs})

        if len(self.writers) < 2:
            raise RuntimeError('Need at least 2 writers with >=2 genuine images across provided roots.')

    def __len__(self):
        return 10000

    def __getitem__(self, idx):
        from PIL import Image

        # Balance positives/negatives
        want_pos = random.random() < 0.5

        if want_pos:
            w = random.choice(self.writers)
            p1, p2 = random.sample(w['genuines'], 2)
            label = 1.0
        else:
            # Prefer skilled-forgery negatives (G,F) if available
            w = random.choice(self.writers)
            if len(w['forgeries']) > 0:
                p1 = random.choice(w['genuines'])
                p2 = random.choice(w['forgeries'])
                label = 0.0
            else:
                # Fallback: different-writer negative
                w1, w2 = random.sample(self.writers, 2)
                p1 = random.choice(w1['genuines'])
                p2 = random.choice(w2['genuines'])
                label = 0.0

        img1 = Image.open(p1).convert('L')
        img2 = Image.open(p2).convert('L')

        img1 = preprocess_signature(img1)
        img2 = preprocess_signature(img2)

        img1 = self.transform(img1)
        img2 = self.transform(img2)
        return img1, img2, torch.tensor(label, dtype=torch.float32)


def _parse_kv_csv(s: str) -> Dict[str, str]:
    out: Dict[str, str] = {}
    if not s:
        return out
    parts = [p.strip() for p in s.split(',') if p.strip()]
    for p in parts:
        if '=' not in p:
            raise ValueError(f'Invalid item "{p}"; expected key=value')
        k, v = p.split('=', 1)
        out[k.strip()] = v.strip()
    return out


def _parse_int_map(s: str) -> Dict[str, int]:
    raw = _parse_kv_csv(s)
    return {k: int(v) for k, v in raw.items()}


def parse_args():
    ap = argparse.ArgumentParser()

    ap.add_argument('--root', help='Single dataset root (used if --roots not provided)')
    ap.add_argument(
        '--roots',
        default=None,
        help=(
            'Either a comma-separated list of paths, or key=path pairs. Examples: '
            '"data/BHSig260-Bengali/BHSig260-Bengali,data/BHSig260-Hindi/BHSig260-Hindi" '
            'or "bengali=...,hindi=...,cedar=..."'
        ),
    )
    ap.add_argument('--train_writers', type=int, default=50, help='Writers from FIRST root used for training (legacy)')
    ap.add_argument(
        '--train_writers_map',
        default=None,
        help='Per-dataset train writer counts, e.g. "bengali=50,hindi=100,cedar=30"',
    )

    ap.add_argument('--batch', type=int, default=64)
    ap.add_argument('--epochs', type=int, default=30)
    ap.add_argument('--lr', type=float, default=1e-4)
    ap.add_argument('--margin', type=float, default=1.0)
    ap.add_argument('--gpu', type=int, default=0)
    ap.add_argument('--out', default='checkpoints/verification.pt')

    ap.add_argument('--val_every', type=int, default=1, help='Validate every N epochs')
    ap.add_argument(
        '--val_max_pairs',
        type=int,
        default=2000,
        help='Limit number of pairs used for train/test during validation (per dataset). Use 0 for no limit.',
    )

    return ap.parse_args()


def _resolve_roots(args) -> Tuple[Dict[str, str], List[str]]:
    if args.roots:
        if '=' in args.roots:
            key_to_root = _parse_kv_csv(args.roots)
            roots_list = list(key_to_root.values())
            return key_to_root, roots_list
        roots_list = [r.strip() for r in args.roots.split(',') if r.strip()]
        return {f'ds{i}': r for i, r in enumerate(roots_list)}, roots_list

    if not args.root:
        raise ValueError('Provide --root or --roots')
    return {'ds0': args.root}, [args.root]


def _maybe_limit_pairs(pairs: List[Tuple[str, str, int]], max_pairs: int) -> List[Tuple[str, str, int]]:
    if max_pairs and max_pairs > 0 and len(pairs) > max_pairs:
        return random.sample(pairs, max_pairs)
    return pairs


def _eval_dataset(
    model: HybridEncoder,
    device,
    root: str,
    train_writers: int,
    tag: str,
    val_max_pairs: int,
):
    writers = list_writer_dirs(root)
    train_w = writers[:train_writers]
    test_w = writers[train_writers:]

    def gather_pairs(w_subset):
        pairs = []
        for w in w_subset:
            pairs.extend(build_fixed_pairs(os.path.join(root, w)))
        return pairs

    train_pairs = _maybe_limit_pairs(gather_pairs(train_w), val_max_pairs)
    test_pairs = _maybe_limit_pairs(gather_pairs(test_w), val_max_pairs)

    from PIL import Image

    def eval_pairs(pairs, label):
        model.eval()
        dists, labs = [], []
        for (p1, p2, lab) in tqdm(pairs, desc=f'Eval {tag}:{label}'):
            img1 = Image.open(p1).convert('L')
            img2 = Image.open(p2).convert('L')

            # Use same preprocessing as training (do_invert=True by default)
            img1 = preprocess_signature(img1, do_invert=True)
            img2 = preprocess_signature(img2, do_invert=True)

            img1 = DEFAULT_TRANSFORM(img1).unsqueeze(0).to(device)
            img2 = DEFAULT_TRANSFORM(img2).unsqueeze(0).to(device)

            with torch.no_grad():
                f1, f2 = model(img1), model(img2)
                dist = (f1 - f2).pow(2).sum().sqrt().item()
            dists.append(dist)
            labs.append(lab)
        return np.array(dists), np.array(labs)

    train_dists, train_labels = eval_pairs(train_pairs, 'train')
    thr_adapt, eer_train = find_adaptive_threshold(train_dists, train_labels)

    test_dists, test_labels = eval_pairs(test_pairs, 'test')

    far, frr = compute_far_frr(test_dists, test_labels, thr_adapt)
    acc = compute_acc(test_dists, test_labels, thr_adapt) * 100

    thr_max, best_acc = find_max_acc_threshold(test_dists, test_labels)
    far_m, frr_m = compute_far_frr(test_dists, test_labels, thr_max)

    print(f'\n[{tag}] writers train={len(train_w)} test={len(test_w)}  (pairs train={len(train_pairs)} test={len(test_pairs)})')
    print(f'Ours (Adaptive) Thr {thr_adapt:.3f}  ACC {acc:.2f}%  FRR {frr:.4f}  FAR {far:.4f}  EER-train {eer_train:.4f}')
    print(f'Ours (Max)      Thr {thr_max:.3f}  ACC {best_acc*100:.2f}%  FRR {frr_m:.4f}  FAR {far_m:.4f}')


def main():
    args = parse_args()
    key_to_root, roots_list = _resolve_roots(args)

    device = torch.device(f'cuda:{args.gpu}' if torch.cuda.is_available() else 'cpu')
    out_dir = os.path.dirname(args.out)
    if out_dir:
        os.makedirs(out_dir, exist_ok=True)

    tw_map = _parse_int_map(args.train_writers_map) if args.train_writers_map else None
    train_ds = CombinedRandomPairDataset(
        key_to_root=key_to_root,
        train_writers_map=tw_map,
        default_train_writers=args.train_writers,
    )
    dl_train = DataLoader(train_ds, batch_size=args.batch, shuffle=True, num_workers=4)

    model = HybridEncoder().to(device)
    criterion = ContrastiveLoss(margin=args.margin)
    optimizer = torch.optim.Adam(model.parameters(), lr=args.lr)
    scheduler = torch.optim.lr_scheduler.ExponentialLR(optimizer, gamma=0.95)

    best_loss = float('inf')
    patience_counter = 0

    def run_validation(epoch: int):
        print(f'\n--- Validation (epoch {epoch}) ---')
        if args.train_writers_map:
            tw_map = _parse_int_map(args.train_writers_map)
            for key, root in key_to_root.items():
                if key not in tw_map:
                    print(f'Skipping validation for {key} (no entry in --train_writers_map)')
                    continue
                _eval_dataset(model, device, root, train_writers=tw_map[key], tag=key, val_max_pairs=args.val_max_pairs)
        else:
            primary_key = next(iter(key_to_root.keys()))
            primary_root = key_to_root[primary_key]
            _eval_dataset(model, device, primary_root, train_writers=args.train_writers, tag=primary_key, val_max_pairs=args.val_max_pairs)

    for epoch in range(args.epochs):
        model.train()
        running_loss = 0.0
        for img1, img2, label in tqdm(dl_train, desc=f'Epoch {epoch}'):
            img1, img2, label = img1.to(device), img2.to(device), label.to(device)
            f1, f2 = model(img1), model(img2)
            dist = (f1 - f2).pow(2).sum(1).sqrt()
            loss = criterion(dist, label)
            optimizer.zero_grad()
            loss.backward()
            optimizer.step()
            running_loss += loss.item()
        
        avg_loss = running_loss / len(dl_train)
        scheduler.step()
        print(f'Epoch {epoch} loss {avg_loss:.4f}')

        if args.val_every > 0 and ((epoch + 1) % args.val_every == 0):
            run_validation(epoch)

        # Early stopping logic from paper
        if avg_loss < best_loss:
            best_loss = avg_loss
            patience_counter = 0
            torch.save(model.state_dict(), args.out)
            print(f'Loss improved to {avg_loss:.4f}, saving model to {args.out}')
        else:
            patience_counter += 1
            if patience_counter >= 10:
                print(f'Early stopping at epoch {epoch+1} as loss has not improved for 10 epochs.')
                break

    torch.save(model.state_dict(), args.out)
    print('Saved to', args.out)


if __name__ == '__main__':
    main()
