#!/usr/bin/env python
"""Improved Writer-independent offline signature verification training.

Key improvements over v1:
1. Data augmentation (rotation, scaling, translation, noise)
2. Online pair mining (fresh pairs each epoch)
3. Hard negative mining (focus on difficult forgery cases)
4. Weight decay regularization
5. Learning rate warmup + cosine annealing
6. More pairs per epoch

Usage:
python -m sigverify.train.train_verification_v2 \
    --roots "bengali=data/BHSig260-Bengali/BHSig260-Bengali,hindi=data/BHSig260-Hindi/BHSig260-Hindi,cedar=data/CEDAR/CEDAR" \
    --train_writers_map "bengali=50,hindi=100,cedar=30" \
    --epochs 100 --lr 1e-4 --batch 32 --val_every 5 --gpu 0
"""

import argparse
import glob
import os
import random
from itertools import combinations
from typing import Dict, List, Tuple, Optional

import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.utils.data import DataLoader, Dataset
from torchvision import transforms
from PIL import Image
from tqdm import tqdm

from sigverify.datasets.preprocess import preprocess_signature
from sigverify.models.hybrid_encoder import HybridEncoder
from sigverify.utils.losses import ContrastiveLoss
from sigverify.utils.metrics import (
    compute_acc,
    compute_far_frr,
    find_adaptive_threshold,
    find_max_acc_threshold,
)


# =============================================================================
# Data Augmentation
# =============================================================================

class SignatureAugmentation:
    """Data augmentation for signature images."""
    
    def __init__(self, p=0.5):
        self.p = p
        
    def __call__(self, img: Image.Image) -> Image.Image:
        """Apply random augmentations to a grayscale signature image."""
        if random.random() > self.p:
            return img
            
        # Random rotation (-10 to +10 degrees)
        if random.random() < 0.5:
            angle = random.uniform(-10, 10)
            img = img.rotate(angle, fillcolor=255, expand=False)
        
        # Random scaling (0.9 to 1.1)
        if random.random() < 0.5:
            scale = random.uniform(0.9, 1.1)
            w, h = img.size
            new_w, new_h = int(w * scale), int(h * scale)
            img = img.resize((new_w, new_h), Image.BILINEAR)
            # Pad or crop to original size
            if new_w != w or new_h != h:
                canvas = Image.new('L', (w, h), 255)
                x_off = (w - new_w) // 2
                y_off = (h - new_h) // 2
                if x_off >= 0 and y_off >= 0:
                    canvas.paste(img, (x_off, y_off))
                else:
                    # Crop center
                    left = max(0, -x_off)
                    top = max(0, -y_off)
                    img = img.crop((left, top, left + w, top + h))
                    canvas = img
                img = canvas
        
        # Random translation (-5 to +5 pixels)
        if random.random() < 0.3:
            tx = random.randint(-5, 5)
            ty = random.randint(-5, 5)
            img = img.transform(img.size, Image.AFFINE, (1, 0, tx, 0, 1, ty), fillcolor=255)
        
        # Random noise
        if random.random() < 0.2:
            arr = np.array(img, dtype=np.float32)
            noise = np.random.normal(0, 5, arr.shape)
            arr = np.clip(arr + noise, 0, 255).astype(np.uint8)
            img = Image.fromarray(arr, mode='L')
        
        return img


# =============================================================================
# Dataset Classes
# =============================================================================

def list_writer_dirs(root: str) -> List[str]:
    return sorted([d for d in os.listdir(root) if os.path.isdir(os.path.join(root, d))])


def _is_bhsig_file(name: str) -> bool:
    return ('-G-' in name) or ('-F-' in name)


def get_writer_images(writer_dir: str) -> Tuple[List[str], List[str]]:
    """Get genuine and forgery images for a writer directory."""
    imgs = sorted(glob.glob(os.path.join(writer_dir, '*')))
    if len(imgs) == 0:
        return [], []
    
    base_names = [os.path.basename(p) for p in imgs]
    
    # Check if BHSig or CEDAR format
    if any(_is_bhsig_file(n) for n in base_names):
        # BHSig format: *-G-* for genuine, *-F-* for forgery
        genuine = [p for p, n in zip(imgs, base_names) if '-G-' in n]
        forgery = [p for p, n in zip(imgs, base_names) if '-F-' in n]
    else:
        # CEDAR format: original_* for genuine, forgeries_* for forgery
        genuine = [p for p, n in zip(imgs, base_names) if n.startswith('original_')]
        forgery = [p for p, n in zip(imgs, base_names) if n.startswith('forgeries_')]
    
    return genuine, forgery


class OnlinePairDataset(Dataset):
    """Dataset that generates pairs online during training with augmentation."""
    
    def __init__(
        self,
        roots: Dict[str, str],
        train_writers_map: Dict[str, int],
        pairs_per_epoch: int = 20000,
        augment: bool = True,
        hard_negative_ratio: float = 0.3,
    ):
        """
        Args:
            roots: Dict mapping dataset key to root path
            train_writers_map: Dict mapping dataset key to number of training writers
            pairs_per_epoch: Number of pairs to generate per epoch
            augment: Whether to apply data augmentation
            hard_negative_ratio: Ratio of hard negatives (skilled forgeries) vs random negatives
        """
        self.pairs_per_epoch = pairs_per_epoch
        self.augment = augment
        self.hard_negative_ratio = hard_negative_ratio
        
        if augment:
            self.augmentor = SignatureAugmentation(p=0.5)
        
        # Collect writer data from all datasets
        self.writers_data = []  # List of (genuine_paths, forgery_paths, dataset_key)
        
        for key, root in roots.items():
            train_writers = train_writers_map.get(key, 50)
            writer_dirs = list_writer_dirs(root)[:train_writers]
            
            for wd in writer_dirs:
                writer_path = os.path.join(root, wd)
                genuine, forgery = get_writer_images(writer_path)
                if len(genuine) >= 2:  # Need at least 2 genuine for positive pairs
                    self.writers_data.append((genuine, forgery, key))
        
        print(f"[OnlinePairDataset] Loaded {len(self.writers_data)} writers from {len(roots)} datasets")
        
        # Generate initial pairs
        self._generate_pairs()
    
    def _generate_pairs(self):
        """Generate balanced pairs for this epoch."""
        self.pairs = []
        half = self.pairs_per_epoch // 2
        
        # Generate genuine pairs (label=1)
        for _ in range(half):
            writer_data = random.choice(self.writers_data)
            genuine, forgery, _ = writer_data
            if len(genuine) >= 2:
                g1, g2 = random.sample(genuine, 2)
                self.pairs.append((g1, g2, 1.0))
        
        # Generate forgery pairs (label=0)
        num_hard = int(half * self.hard_negative_ratio)
        num_random = half - num_hard
        
        # Hard negatives: genuine vs skilled forgery (same writer)
        for _ in range(num_hard):
            writer_data = random.choice(self.writers_data)
            genuine, forgery, _ = writer_data
            if len(genuine) >= 1 and len(forgery) >= 1:
                g = random.choice(genuine)
                f = random.choice(forgery)
                self.pairs.append((g, f, 0.0))
        
        # Random negatives: genuine from different writers
        for _ in range(num_random):
            w1, w2 = random.sample(self.writers_data, 2)
            g1 = random.choice(w1[0])
            g2 = random.choice(w2[0])
            self.pairs.append((g1, g2, 0.0))
        
        random.shuffle(self.pairs)
    
    def __len__(self):
        return len(self.pairs)
    
    def __getitem__(self, idx):
        path1, path2, label = self.pairs[idx]
        
        img1 = Image.open(path1)
        img2 = Image.open(path2)
        
        # Preprocess
        img1 = preprocess_signature(img1, do_invert=True)
        img2 = preprocess_signature(img2, do_invert=True)
        
        # Augment
        if self.augment:
            img1 = self.augmentor(img1)
            img2 = self.augmentor(img2)
        
        # Convert to tensor
        arr1 = np.array(img1, dtype=np.float32) / 255.0
        arr2 = np.array(img2, dtype=np.float32) / 255.0
        
        t1 = torch.from_numpy(arr1).unsqueeze(0)  # (1, H, W)
        t2 = torch.from_numpy(arr2).unsqueeze(0)
        
        return t1, t2, torch.tensor(label, dtype=torch.float32)
    
    def regenerate_pairs(self):
        """Call at the start of each epoch to get fresh pairs."""
        self._generate_pairs()


class EvalPairDataset(Dataset):
    """Fixed evaluation pairs (no augmentation)."""
    
    def __init__(self, pairs: List[Tuple[str, str, int]]):
        self.pairs = pairs
    
    def __len__(self):
        return len(self.pairs)
    
    def __getitem__(self, idx):
        path1, path2, label = self.pairs[idx]
        
        img1 = Image.open(path1)
        img2 = Image.open(path2)
        
        img1 = preprocess_signature(img1, do_invert=True)
        img2 = preprocess_signature(img2, do_invert=True)
        
        arr1 = np.array(img1, dtype=np.float32) / 255.0
        arr2 = np.array(img2, dtype=np.float32) / 255.0
        
        t1 = torch.from_numpy(arr1).unsqueeze(0)
        t2 = torch.from_numpy(arr2).unsqueeze(0)
        
        return t1, t2, torch.tensor(label, dtype=torch.float32)


def build_fixed_pairs(writer_dir: str, max_pairs_per_class: int = 276) -> List[Tuple[str, str, int]]:
    """Build fixed evaluation pairs for a writer."""
    genuine, forgery = get_writer_images(writer_dir)
    pairs = []
    
    # Genuine-Genuine pairs (label=1)
    if len(genuine) >= 2:
        gg_pairs = list(combinations(genuine, 2))
        if len(gg_pairs) > max_pairs_per_class:
            gg_pairs = random.sample(gg_pairs, max_pairs_per_class)
        for g1, g2 in gg_pairs:
            pairs.append((g1, g2, 1))
    
    # Genuine-Forgery pairs (label=0)
    if len(genuine) >= 1 and len(forgery) >= 1:
        gf_pairs = [(g, f) for g in genuine for f in forgery]
        if len(gf_pairs) > max_pairs_per_class:
            gf_pairs = random.sample(gf_pairs, max_pairs_per_class)
        for g, f in gf_pairs:
            pairs.append((g, f, 0))
    
    return pairs


# =============================================================================
# Learning Rate Scheduler with Warmup
# =============================================================================

class WarmupCosineScheduler:
    """Learning rate scheduler with linear warmup and cosine annealing."""
    
    def __init__(self, optimizer, warmup_epochs: int, total_epochs: int, base_lr: float, min_lr: float = 1e-6):
        self.optimizer = optimizer
        self.warmup_epochs = warmup_epochs
        self.total_epochs = total_epochs
        self.base_lr = base_lr
        self.min_lr = min_lr
        self.current_epoch = 0
    
    def step(self):
        self.current_epoch += 1
        lr = self._get_lr()
        for param_group in self.optimizer.param_groups:
            param_group['lr'] = lr
        return lr
    
    def _get_lr(self):
        if self.current_epoch <= self.warmup_epochs:
            # Linear warmup
            return self.base_lr * self.current_epoch / self.warmup_epochs
        else:
            # Cosine annealing
            progress = (self.current_epoch - self.warmup_epochs) / (self.total_epochs - self.warmup_epochs)
            return self.min_lr + 0.5 * (self.base_lr - self.min_lr) * (1 + np.cos(np.pi * progress))


# =============================================================================
# Evaluation
# =============================================================================

def evaluate_dataset(
    model: nn.Module,
    device: torch.device,
    root: str,
    train_writers: int,
    tag: str,
    val_max_pairs: int = 2000,
):
    """Evaluate on a single dataset."""
    model.eval()
    
    writer_dirs = list_writer_dirs(root)
    train_dirs = writer_dirs[:train_writers]
    test_dirs = writer_dirs[train_writers:]
    
    if len(test_dirs) == 0:
        print(f"[{tag}] No test writers available!")
        return
    
    # Build evaluation pairs
    train_pairs = []
    for wd in train_dirs:
        train_pairs.extend(build_fixed_pairs(os.path.join(root, wd)))
    
    test_pairs = []
    for wd in test_dirs:
        test_pairs.extend(build_fixed_pairs(os.path.join(root, wd)))
    
    # Limit pairs if needed
    if len(train_pairs) > val_max_pairs:
        train_pairs = random.sample(train_pairs, val_max_pairs)
    if len(test_pairs) > val_max_pairs:
        test_pairs = random.sample(test_pairs, val_max_pairs)
    
    def compute_distances(pairs):
        ds = EvalPairDataset(pairs)
        dl = DataLoader(ds, batch_size=1, shuffle=False, num_workers=0)
        
        distances = []
        labels = []
        
        with torch.no_grad():
            for img1, img2, label in tqdm(dl, desc=f'Eval {tag}', leave=False):
                img1, img2 = img1.to(device), img2.to(device)
                f1, f2 = model(img1), model(img2)
                dist = (f1 - f2).pow(2).sum(1).sqrt().item()
                distances.append(dist)
                labels.append(label.item())
        
        return np.array(distances), np.array(labels)
    
    train_dist, train_labels = compute_distances(train_pairs)
    test_dist, test_labels = compute_distances(test_pairs)
    
    # Find adaptive threshold on training writers
    thr_adapt, eer_train = find_adaptive_threshold(train_dist, train_labels)
    
    # Evaluate on test writers
    far, frr = compute_far_frr(test_dist, test_labels, thr_adapt)
    acc = compute_acc(test_dist, test_labels, thr_adapt)
    
    # Find max accuracy threshold on test set (oracle)
    thr_max, acc_max = find_max_acc_threshold(test_dist, test_labels)
    far_max, frr_max = compute_far_frr(test_dist, test_labels, thr_max)
    
    print(f"\n[{tag}] writers train={len(train_dirs)} test={len(test_dirs)}  "
          f"(pairs train={len(train_pairs)} test={len(test_pairs)})")
    print(f"Ours (Adaptive) Thr {thr_adapt:.3f}  ACC {acc*100:.2f}%  FRR {frr:.4f}  FAR {far:.4f}  EER-train {eer_train:.4f}")
    print(f"Ours (Max)      Thr {thr_max:.3f}  ACC {acc_max*100:.2f}%  FRR {frr_max:.4f}  FAR {far_max:.4f}")
    
    return acc, eer_train


# =============================================================================
# Main Training Loop
# =============================================================================

def parse_args():
    ap = argparse.ArgumentParser()
    ap.add_argument('--root', default=None, help='Single dataset root')
    ap.add_argument('--roots', default=None, help='Multiple roots: "key1=path1,key2=path2"')
    ap.add_argument('--train_writers', type=int, default=50, help='Training writers (single root)')
    ap.add_argument('--train_writers_map', default=None, help='Per-dataset training writers: "key1=N1,key2=N2"')
    ap.add_argument('--pairs_per_epoch', type=int, default=20000, help='Number of pairs per epoch')
    ap.add_argument('--hard_negative_ratio', type=float, default=0.5, help='Ratio of hard negatives')
    ap.add_argument('--batch', type=int, default=32)
    ap.add_argument('--epochs', type=int, default=100)
    ap.add_argument('--lr', type=float, default=1e-4)
    ap.add_argument('--weight_decay', type=float, default=1e-4, help='L2 regularization')
    ap.add_argument('--warmup_epochs', type=int, default=5, help='LR warmup epochs')
    ap.add_argument('--margin', type=float, default=1.0)
    ap.add_argument('--val_every', type=int, default=5)
    ap.add_argument('--val_max_pairs', type=int, default=2000)
    ap.add_argument('--patience', type=int, default=15, help='Early stopping patience')
    ap.add_argument('--gpu', type=int, default=0)
    ap.add_argument('--out', default='checkpoints/verify_v2.pt')
    ap.add_argument('--no_augment', action='store_true', help='Disable data augmentation')
    return ap.parse_args()


def _parse_roots(s: str) -> Dict[str, str]:
    result = {}
    for item in s.split(','):
        key, path = item.split('=')
        result[key.strip()] = path.strip()
    return result


def _parse_int_map(s: str) -> Dict[str, int]:
    result = {}
    for item in s.split(','):
        key, val = item.split('=')
        result[key.strip()] = int(val.strip())
    return result


def main():
    args = parse_args()
    device = torch.device(f'cuda:{args.gpu}' if torch.cuda.is_available() else 'cpu')
    os.makedirs(os.path.dirname(args.out) if os.path.dirname(args.out) else '.', exist_ok=True)
    
    # Parse roots
    if args.roots:
        key_to_root = _parse_roots(args.roots)
    elif args.root:
        key_to_root = {'default': args.root}
    else:
        raise ValueError("Provide --root or --roots")
    
    # Parse train writers map
    if args.train_writers_map:
        train_writers_map = _parse_int_map(args.train_writers_map)
    else:
        train_writers_map = {k: args.train_writers for k in key_to_root}
    
    print(f"Datasets: {list(key_to_root.keys())}")
    print(f"Train writers: {train_writers_map}")
    print(f"Device: {device}")
    
    # Create dataset
    train_dataset = OnlinePairDataset(
        roots=key_to_root,
        train_writers_map=train_writers_map,
        pairs_per_epoch=args.pairs_per_epoch,
        augment=not args.no_augment,
        hard_negative_ratio=args.hard_negative_ratio,
    )
    
    train_loader = DataLoader(
        train_dataset,
        batch_size=args.batch,
        shuffle=True,
        num_workers=4,
        pin_memory=True,
    )
    
    # Create model
    model = HybridEncoder().to(device)
    
    # Loss and optimizer with weight decay
    criterion = ContrastiveLoss(margin=args.margin)
    optimizer = torch.optim.AdamW(
        model.parameters(),
        lr=args.lr,
        weight_decay=args.weight_decay,
    )
    
    # Learning rate scheduler
    scheduler = WarmupCosineScheduler(
        optimizer,
        warmup_epochs=args.warmup_epochs,
        total_epochs=args.epochs,
        base_lr=args.lr,
    )
    
    # Training loop
    best_loss = float('inf')
    patience_counter = 0
    
    for epoch in range(args.epochs):
        # Regenerate pairs each epoch
        train_dataset.regenerate_pairs()
        
        model.train()
        running_loss = 0.0
        
        pbar = tqdm(train_loader, desc=f'Epoch {epoch}')
        for img1, img2, label in pbar:
            img1, img2, label = img1.to(device), img2.to(device), label.to(device)
            
            f1, f2 = model(img1), model(img2)
            dist = (f1 - f2).pow(2).sum(1).sqrt()
            loss = criterion(dist, label)
            
            optimizer.zero_grad()
            loss.backward()
            
            # Gradient clipping
            torch.nn.utils.clip_grad_norm_(model.parameters(), max_norm=1.0)
            
            optimizer.step()
            running_loss += loss.item()
            
            pbar.set_postfix({'loss': f'{loss.item():.4f}'})
        
        # Update learning rate
        current_lr = scheduler.step()
        
        avg_loss = running_loss / len(train_loader)
        print(f'Epoch {epoch} loss {avg_loss:.4f}  lr {current_lr:.2e}')
        
        # Validation
        if args.val_every > 0 and ((epoch + 1) % args.val_every == 0):
            print(f'\n--- Validation (epoch {epoch}) ---')
            for key, root in key_to_root.items():
                tw = train_writers_map.get(key, args.train_writers)
                evaluate_dataset(model, device, root, tw, key, args.val_max_pairs)
        
        # Early stopping based on training loss
        if avg_loss < best_loss:
            best_loss = avg_loss
            patience_counter = 0
            torch.save(model.state_dict(), args.out)
            print(f'Loss improved to {avg_loss:.4f}, saving model to {args.out}')
        else:
            patience_counter += 1
            if patience_counter >= args.patience:
                print(f'Early stopping at epoch {epoch+1} (patience={args.patience})')
                break
    
    print(f'Training complete. Best model saved to {args.out}')


if __name__ == '__main__':
    main()
