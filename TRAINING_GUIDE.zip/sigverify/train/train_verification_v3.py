#!/usr/bin/env python
"""Enhanced Writer-independent offline signature verification training V3.

Key improvements over v2:
1. Improved loss function with soft margin and weighted genuine pairs
2. Better threshold selection using ROC-optimal and percentile methods
3. Adaptive hard negative mining that increases difficulty over training
4. More aggressive data augmentation
5. Better distance distribution diagnostics
6. Lower margin (0.5) for better convergence with L2-normalized features
7. More training pairs per epoch
8. Cosine similarity option for better metric learning

Usage:
python -m sigverify.train.train_verification_v3 \
    --roots "bengali=data/BHSig260-Bengali/BHSig260-Bengali,hindi=data/BHSig260-Hindi/BHSig260-Hindi,cedar=data/CEDAR/CEDAR" \
    --train_writers_map "bengali=50,hindi=100,cedar=30" \
    --epochs 150 --lr 3e-4 --batch 64 --val_every 5 --gpu 0
"""

import argparse
import glob
import os
import random
from itertools import combinations
from typing import Dict, List, Tuple, Optional

import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.utils.data import DataLoader, Dataset
from torch.utils.tensorboard import SummaryWriter
from torchvision import transforms
from PIL import Image
from tqdm import tqdm

from sigverify.datasets.preprocess import preprocess_signature
from sigverify.models.hybrid_encoder import HybridEncoder
from sigverify.utils.losses import ContrastiveLoss, CombinedVerificationLoss
from sigverify.utils.metrics import (
    compute_acc,
    compute_far_frr,
    find_adaptive_threshold,
    find_max_acc_threshold,
    find_roc_optimal_threshold,
    get_distance_statistics,
    print_distance_stats,
)


# =============================================================================
# Enhanced Data Augmentation
# =============================================================================

class EnhancedSignatureAugmentation:
    """Enhanced data augmentation for signature images."""
    
    def __init__(self, p=0.7, strength='medium'):
        """
        Args:
            p: Base probability of applying any augmentation
            strength: 'light', 'medium', 'strong' - controls augmentation intensity
        """
        self.p = p
        self.strength = strength
        
        # Set parameters based on strength
        if strength == 'light':
            self.rot_range = (-5, 5)
            self.scale_range = (0.95, 1.05)
            self.trans_range = (-3, 3)
            self.noise_std = 3
        elif strength == 'medium':
            self.rot_range = (-10, 10)
            self.scale_range = (0.9, 1.1)
            self.trans_range = (-5, 5)
            self.noise_std = 5
        else:  # strong
            self.rot_range = (-15, 15)
            self.scale_range = (0.85, 1.15)
            self.trans_range = (-8, 8)
            self.noise_std = 8
        
    def __call__(self, img: Image.Image) -> Image.Image:
        """Apply random augmentations to a grayscale signature image."""
        if random.random() > self.p:
            return img
        
        # Random rotation
        if random.random() < 0.6:
            angle = random.uniform(*self.rot_range)
            img = img.rotate(angle, fillcolor=255, expand=False)
        
        # Random scaling
        if random.random() < 0.5:
            scale = random.uniform(*self.scale_range)
            w, h = img.size
            new_w, new_h = int(w * scale), int(h * scale)
            img = img.resize((new_w, new_h), Image.BILINEAR)
            # Pad or crop to original size
            if new_w != w or new_h != h:
                canvas = Image.new('L', (w, h), 255)
                x_off = (w - new_w) // 2
                y_off = (h - new_h) // 2
                if x_off >= 0 and y_off >= 0:
                    canvas.paste(img, (x_off, y_off))
                else:
                    # Crop center
                    left = max(0, -x_off)
                    top = max(0, -y_off)
                    right = min(new_w, w - x_off)
                    bottom = min(new_h, h - y_off)
                    img = img.crop((left, top, right, bottom))
                    canvas.paste(img, (max(0, x_off), max(0, y_off)))
                img = canvas
        
        # Random translation
        if random.random() < 0.4:
            tx = random.randint(*self.trans_range)
            ty = random.randint(*self.trans_range)
            img = img.transform(img.size, Image.AFFINE, (1, 0, tx, 0, 1, ty), fillcolor=255)
        
        # Random noise
        if random.random() < 0.3:
            arr = np.array(img, dtype=np.float32)
            noise = np.random.normal(0, self.noise_std, arr.shape)
            arr = np.clip(arr + noise, 0, 255).astype(np.uint8)
            img = Image.fromarray(arr, mode='L')
        
        # Random brightness/contrast adjustment
        if random.random() < 0.3:
            arr = np.array(img, dtype=np.float32)
            # Brightness
            brightness = random.uniform(-10, 10)
            arr = arr + brightness
            # Contrast
            contrast = random.uniform(0.9, 1.1)
            arr = (arr - 128) * contrast + 128
            arr = np.clip(arr, 0, 255).astype(np.uint8)
            img = Image.fromarray(arr, mode='L')
        
        # Morphological operations (erosion/dilation to simulate pen thickness variation)
        if random.random() < 0.2:
            from PIL import ImageFilter
            if random.random() < 0.5:
                img = img.filter(ImageFilter.MinFilter(3))  # Thicken strokes
            else:
                img = img.filter(ImageFilter.MaxFilter(3))  # Thin strokes
        
        return img


# =============================================================================
# Dataset Classes
# =============================================================================

def list_writer_dirs(root: str) -> List[str]:
    return sorted([d for d in os.listdir(root) if os.path.isdir(os.path.join(root, d))])


def _is_bhsig_file(name: str) -> bool:
    return ('-G-' in name) or ('-F-' in name)


def get_writer_images(writer_dir: str) -> Tuple[List[str], List[str]]:
    """Get genuine and forgery images for a writer directory."""
    imgs = sorted(glob.glob(os.path.join(writer_dir, '*')))
    if len(imgs) == 0:
        return [], []
    
    base_names = [os.path.basename(p) for p in imgs]
    
    # Check if BHSig or CEDAR format
    if any(_is_bhsig_file(n) for n in base_names):
        # BHSig format: *-G-* for genuine, *-F-* for forgery
        genuine = [p for p, n in zip(imgs, base_names) if '-G-' in n]
        forgery = [p for p, n in zip(imgs, base_names) if '-F-' in n]
    else:
        # CEDAR format: original_* for genuine, forgeries_* for forgery
        genuine = [p for p, n in zip(imgs, base_names) if n.startswith('original_')]
        forgery = [p for p, n in zip(imgs, base_names) if n.startswith('forgeries_')]
    
    return genuine, forgery


class OnlinePairDatasetV3(Dataset):
    """Enhanced dataset with adaptive hard mining and better balance."""
    
    def __init__(
        self,
        roots: Dict[str, str],
        train_writers_map: Dict[str, int],
        pairs_per_epoch: int = 30000,
        augment: bool = True,
        augment_strength: str = 'medium',
        hard_negative_ratio: float = 0.6,  # Increased from 0.3
        epoch: int = 0,
    ):
        """
        Args:
            roots: Dict mapping dataset key to root path
            train_writers_map: Dict mapping dataset key to number of training writers
            pairs_per_epoch: Number of pairs to generate per epoch
            augment: Whether to apply data augmentation
            augment_strength: 'light', 'medium', 'strong'
            hard_negative_ratio: Ratio of hard negatives (skilled forgeries)
            epoch: Current epoch (for curriculum learning)
        """
        self.pairs_per_epoch = pairs_per_epoch
        self.augment = augment
        self.base_hard_ratio = hard_negative_ratio
        self.epoch = epoch
        
        if augment:
            self.augmentor = EnhancedSignatureAugmentation(p=0.7, strength=augment_strength)
        
        # Collect writer data from all datasets
        self.writers_data = []  # List of (genuine_paths, forgery_paths, dataset_key, writer_id)
        self.writer_id_counter = 0
        
        for key, root in roots.items():
            train_writers = train_writers_map.get(key, 50)
            writer_dirs = list_writer_dirs(root)[:train_writers]
            
            for wd in writer_dirs:
                writer_path = os.path.join(root, wd)
                genuine, forgery = get_writer_images(writer_path)
                if len(genuine) >= 2:  # Need at least 2 genuine for positive pairs
                    self.writers_data.append((genuine, forgery, key, self.writer_id_counter))
                    self.writer_id_counter += 1
        
        print(f"[OnlinePairDatasetV3] Loaded {len(self.writers_data)} writers from {len(roots)} datasets")
        
        # Generate initial pairs
        self._generate_pairs()
    
    def get_hard_ratio(self) -> float:
        """Adaptive hard ratio - increases over training."""
        # Start with 50% of target, increase to 100% by epoch 50
        progress = min(1.0, self.epoch / 50)
        min_ratio = 0.3
        return min_ratio + (self.base_hard_ratio - min_ratio) * progress
    
    def _generate_pairs(self):
        """Generate balanced pairs for this epoch with curriculum learning."""
        self.pairs = []
        self.writer_labels = []  # For potential triplet loss
        
        half = self.pairs_per_epoch // 2
        hard_ratio = self.get_hard_ratio()
        
        # Generate genuine pairs (label=1)
        for _ in range(half):
            idx = random.randrange(len(self.writers_data))
            writer_data = self.writers_data[idx]
            genuine, forgery, _, writer_id = writer_data
            if len(genuine) >= 2:
                g1, g2 = random.sample(genuine, 2)
                self.pairs.append((g1, g2, 1.0))
                self.writer_labels.append(writer_id)
        
        # Generate forgery pairs (label=0)
        num_hard = int(half * hard_ratio)
        num_random = half - num_hard
        
        # Hard negatives: genuine vs skilled forgery (same writer)
        hard_count = 0
        attempts = 0
        max_attempts = num_hard * 3
        while hard_count < num_hard and attempts < max_attempts:
            attempts += 1
            idx = random.randrange(len(self.writers_data))
            writer_data = self.writers_data[idx]
            genuine, forgery, _, writer_id = writer_data
            if len(genuine) >= 1 and len(forgery) >= 1:
                g = random.choice(genuine)
                f = random.choice(forgery)
                self.pairs.append((g, f, 0.0))
                self.writer_labels.append(writer_id)
                hard_count += 1
        
        # Random negatives: genuine from different writers
        for _ in range(num_random + (num_hard - hard_count)):
            idx1, idx2 = random.sample(range(len(self.writers_data)), 2)
            w1, w2 = self.writers_data[idx1], self.writers_data[idx2]
            g1 = random.choice(w1[0])
            g2 = random.choice(w2[0])
            self.pairs.append((g1, g2, 0.0))
            self.writer_labels.append(-1)  # Cross-writer, no valid label
        
        # Shuffle pairs
        combined = list(zip(self.pairs, self.writer_labels))
        random.shuffle(combined)
        self.pairs, self.writer_labels = zip(*combined)
        self.pairs = list(self.pairs)
        self.writer_labels = list(self.writer_labels)
    
    def __len__(self):
        return len(self.pairs)
    
    def __getitem__(self, idx):
        path1, path2, label = self.pairs[idx]
        
        img1 = Image.open(path1)
        img2 = Image.open(path2)
        
        # Preprocess
        img1 = preprocess_signature(img1, do_invert=True)
        img2 = preprocess_signature(img2, do_invert=True)
        
        # Augment
        if self.augment:
            img1 = self.augmentor(img1)
            img2 = self.augmentor(img2)
        
        # Convert to tensor
        arr1 = np.array(img1, dtype=np.float32) / 255.0
        arr2 = np.array(img2, dtype=np.float32) / 255.0
        
        t1 = torch.from_numpy(arr1).unsqueeze(0)  # (1, H, W)
        t2 = torch.from_numpy(arr2).unsqueeze(0)
        
        return t1, t2, torch.tensor(label, dtype=torch.float32)
    
    def regenerate_pairs(self, epoch: int = None):
        """Call at the start of each epoch to get fresh pairs."""
        if epoch is not None:
            self.epoch = epoch
        self._generate_pairs()


class EvalPairDataset(Dataset):
    """Fixed evaluation pairs (no augmentation)."""
    
    def __init__(self, pairs: List[Tuple[str, str, int]]):
        self.pairs = pairs
    
    def __len__(self):
        return len(self.pairs)
    
    def __getitem__(self, idx):
        path1, path2, label = self.pairs[idx]
        
        img1 = Image.open(path1)
        img2 = Image.open(path2)
        
        img1 = preprocess_signature(img1, do_invert=True)
        img2 = preprocess_signature(img2, do_invert=True)
        
        arr1 = np.array(img1, dtype=np.float32) / 255.0
        arr2 = np.array(img2, dtype=np.float32) / 255.0
        
        t1 = torch.from_numpy(arr1).unsqueeze(0)
        t2 = torch.from_numpy(arr2).unsqueeze(0)
        
        return t1, t2, torch.tensor(label, dtype=torch.float32)


def build_fixed_pairs(writer_dir: str, max_pairs_per_class: int = 500) -> List[Tuple[str, str, int]]:
    """Build fixed evaluation pairs for a writer."""
    genuine, forgery = get_writer_images(writer_dir)
    pairs = []
    
    # Genuine-Genuine pairs (label=1)
    if len(genuine) >= 2:
        gg_pairs = list(combinations(genuine, 2))
        if len(gg_pairs) > max_pairs_per_class:
            gg_pairs = random.sample(gg_pairs, max_pairs_per_class)
        for g1, g2 in gg_pairs:
            pairs.append((g1, g2, 1))
    
    # Genuine-Forgery pairs (label=0)
    if len(genuine) >= 1 and len(forgery) >= 1:
        gf_pairs = [(g, f) for g in genuine for f in forgery]
        if len(gf_pairs) > max_pairs_per_class:
            gf_pairs = random.sample(gf_pairs, max_pairs_per_class)
        for g, f in gf_pairs:
            pairs.append((g, f, 0))
    
    return pairs


# =============================================================================
# Learning Rate Scheduler with Warmup
# =============================================================================

class WarmupCosineScheduler:
    """Learning rate scheduler with linear warmup and cosine annealing."""
    
    def __init__(self, optimizer, warmup_epochs: int, total_epochs: int, base_lr: float, min_lr: float = 1e-6):
        self.optimizer = optimizer
        self.warmup_epochs = warmup_epochs
        self.total_epochs = total_epochs
        self.base_lr = base_lr
        self.min_lr = min_lr
        self.current_epoch = 0
    
    def step(self):
        self.current_epoch += 1
        lr = self._get_lr()
        for param_group in self.optimizer.param_groups:
            param_group['lr'] = lr
        return lr
    
    def _get_lr(self):
        if self.current_epoch <= self.warmup_epochs:
            # Linear warmup
            return self.base_lr * self.current_epoch / self.warmup_epochs
        else:
            # Cosine annealing
            progress = (self.current_epoch - self.warmup_epochs) / (self.total_epochs - self.warmup_epochs)
            return self.min_lr + 0.5 * (self.base_lr - self.min_lr) * (1 + np.cos(np.pi * progress))


# =============================================================================
# Evaluation with Enhanced Diagnostics
# =============================================================================

def evaluate_dataset(
    model: nn.Module,
    device: torch.device,
    root: str,
    train_writers: int,
    tag: str,
    val_max_pairs: int = 3000,
    verbose: bool = True,
    writer: SummaryWriter = None,
    global_step: int = 0,
):
    """Evaluate on a single dataset with comprehensive metrics."""
    model.eval()
    
    writer_dirs = list_writer_dirs(root)
    train_dirs = writer_dirs[:train_writers]
    test_dirs = writer_dirs[train_writers:]
    
    if len(test_dirs) == 0:
        print(f"[{tag}] No test writers available!")
        return 0.0, 0.0
    
    # Build evaluation pairs
    train_pairs = []
    for wd in train_dirs:
        train_pairs.extend(build_fixed_pairs(os.path.join(root, wd)))
    
    test_pairs = []
    for wd in test_dirs:
        test_pairs.extend(build_fixed_pairs(os.path.join(root, wd)))
    
    # Limit pairs if needed
    if len(train_pairs) > val_max_pairs:
        train_pairs = random.sample(train_pairs, val_max_pairs)
    if len(test_pairs) > val_max_pairs:
        test_pairs = random.sample(test_pairs, val_max_pairs)
    
    def compute_distances(pairs, desc=""):
        ds = EvalPairDataset(pairs)
        dl = DataLoader(ds, batch_size=32, shuffle=False, num_workers=0)
        
        distances = []
        labels = []
        
        with torch.no_grad():
            for img1, img2, label in tqdm(dl, desc=desc, leave=False):
                img1, img2 = img1.to(device), img2.to(device)
                f1, f2 = model(img1), model(img2)
                dist = (f1 - f2).pow(2).sum(1).sqrt()
                distances.extend(dist.cpu().numpy().tolist())
                labels.extend(label.numpy().tolist())
        
        return np.array(distances), np.array(labels)
    
    train_dist, train_labels = compute_distances(train_pairs, f'Train {tag}')
    test_dist, test_labels = compute_distances(test_pairs, f'Test {tag}')
    
    # Get distance statistics
    train_stats = get_distance_statistics(train_dist, train_labels)
    test_stats = get_distance_statistics(test_dist, test_labels)
    
    if verbose:
        print_distance_stats(train_stats, f"{tag} Train")
        print_distance_stats(test_stats, f"{tag} Test")
    
    # Log to tensorboard
    if writer is not None:
        # Log train distance distributions
        writer.add_scalar(f'{tag}/Train/Distance_Genuine_Mean', train_stats['genuine']['mean'], global_step)
        writer.add_scalar(f'{tag}/Train/Distance_Forgery_Mean', train_stats['forgery']['mean'], global_step)
        writer.add_scalar(f'{tag}/Train/Distance_Genuine_Std', train_stats['genuine']['std'], global_step)
        writer.add_scalar(f'{tag}/Train/Distance_Forgery_Std', train_stats['forgery']['std'], global_step)
        writer.add_scalar(f'{tag}/Train/Fisher_Ratio', train_stats['fisher_ratio'], global_step)
        writer.add_scalar(f'{tag}/Train/Separability', train_stats['separability'], global_step)
        
        # Log test distance distributions
        writer.add_scalar(f'{tag}/Test/Distance_Genuine_Mean', test_stats['genuine']['mean'], global_step)
        writer.add_scalar(f'{tag}/Test/Distance_Forgery_Mean', test_stats['forgery']['mean'], global_step)
        writer.add_scalar(f'{tag}/Test/Distance_Genuine_Std', test_stats['genuine']['std'], global_step)
        writer.add_scalar(f'{tag}/Test/Distance_Forgery_Std', test_stats['forgery']['std'], global_step)
        writer.add_scalar(f'{tag}/Test/Fisher_Ratio', test_stats['fisher_ratio'], global_step)
        writer.add_scalar(f'{tag}/Test/Separability', test_stats['separability'], global_step)
        
        # Log histograms
        writer.add_histogram(f'{tag}/Train/Distance_Genuine', train_dist[train_labels == 1], global_step)
        writer.add_histogram(f'{tag}/Train/Distance_Forgery', train_dist[train_labels == 0], global_step)
        writer.add_histogram(f'{tag}/Test/Distance_Genuine', test_dist[test_labels == 1], global_step)
        writer.add_histogram(f'{tag}/Test/Distance_Forgery', test_dist[test_labels == 0], global_step)
    
    # Method 1: EER-based threshold (traditional)
    thr_eer, eer_train = find_adaptive_threshold(train_dist, train_labels)
    
    # Method 2: ROC-optimal threshold (Youden's J)
    thr_roc, roc_metrics = find_roc_optimal_threshold(train_dist, train_labels)
    
    # Method 3: Max accuracy on train (then apply to test)
    thr_train_max, _ = find_max_acc_threshold(train_dist, train_labels)
    
    # Evaluate all thresholds on test set
    results = {}
    
    for name, thr in [('EER', thr_eer), ('ROC', thr_roc), ('TrainMax', thr_train_max)]:
        far, frr = compute_far_frr(test_dist, test_labels, thr)
        acc = compute_acc(test_dist, test_labels, thr)
        results[name] = {'thr': thr, 'acc': acc, 'far': far, 'frr': frr}
    
    # Oracle: max accuracy on test (upper bound)
    thr_max, acc_max = find_max_acc_threshold(test_dist, test_labels)
    far_max, frr_max = compute_far_frr(test_dist, test_labels, thr_max)
    results['Oracle'] = {'thr': thr_max, 'acc': acc_max, 'far': far_max, 'frr': frr_max}
    
    # Print results
    print(f"\n[{tag}] writers train={len(train_dirs)} test={len(test_dirs)}  "
          f"(pairs train={len(train_pairs)} test={len(test_pairs)})")
    
    best_method = max(['EER', 'ROC', 'TrainMax'], key=lambda k: results[k]['acc'])
    
    for name in ['EER', 'ROC', 'TrainMax', 'Oracle']:
        r = results[name]
        marker = " <-- BEST" if name == best_method else ""
        marker = " (oracle)" if name == 'Oracle' else marker
        print(f"  {name:10s} Thr {r['thr']:.3f}  ACC {r['acc']*100:.2f}%  "
              f"FRR {r['frr']:.4f}  FAR {r['far']:.4f}{marker}")
        
        # Log to tensorboard
        if writer is not None:
            writer.add_scalar(f'{tag}/Test/{name}_Accuracy', r['acc'], global_step)
            writer.add_scalar(f'{tag}/Test/{name}_FAR', r['far'], global_step)
            writer.add_scalar(f'{tag}/Test/{name}_FRR', r['frr'], global_step)
            writer.add_scalar(f'{tag}/Test/{name}_Threshold', r['thr'], global_step)
    
    # Log EER separately
    if writer is not None:
        writer.add_scalar(f'{tag}/Train/EER', eer_train, global_step)
    
    # Return best non-oracle accuracy and EER
    return results[best_method]['acc'], eer_train


# =============================================================================
# Main Training Loop
# =============================================================================

def parse_args():
    ap = argparse.ArgumentParser()
    ap.add_argument('--root', default=None, help='Single dataset root')
    ap.add_argument('--roots', default=None, help='Multiple roots: "key1=path1,key2=path2"')
    ap.add_argument('--train_writers', type=int, default=50, help='Training writers (single root)')
    ap.add_argument('--train_writers_map', default=None, help='Per-dataset training writers: "key1=N1,key2=N2"')
    ap.add_argument('--pairs_per_epoch', type=int, default=30000, help='Number of pairs per epoch')
    ap.add_argument('--hard_negative_ratio', type=float, default=0.6, help='Ratio of hard negatives')
    ap.add_argument('--batch', type=int, default=64)
    ap.add_argument('--epochs', type=int, default=150)
    ap.add_argument('--lr', type=float, default=3e-4)
    ap.add_argument('--weight_decay', type=float, default=1e-4, help='L2 regularization')
    ap.add_argument('--logdir', default='runs/verify_v3', help='TensorBoard log directory')
    ap.add_argument('--warmup_epochs', type=int, default=10, help='LR warmup epochs')
    ap.add_argument('--margin', type=float, default=0.5, help='Contrastive margin (0.5 for L2-norm features)')
    ap.add_argument('--pos_weight', type=float, default=1.5, help='Weight for genuine pairs')
    ap.add_argument('--val_every', type=int, default=5)
    ap.add_argument('--val_max_pairs', type=int, default=3000)
    ap.add_argument('--patience', type=int, default=25, help='Early stopping patience')
    ap.add_argument('--gpu', type=int, default=0)
    ap.add_argument('--out', default='checkpoints/verify_v3.pt')
    ap.add_argument('--no_augment', action='store_true', help='Disable data augmentation')
    ap.add_argument('--augment_strength', default='medium', choices=['light', 'medium', 'strong'])
    ap.add_argument('--resume', default=None, help='Resume from checkpoint')
    return ap.parse_args()


def _parse_roots(s: str) -> Dict[str, str]:
    result = {}
    for item in s.split(','):
        key, path = item.split('=')
        result[key.strip()] = path.strip()
    return result


def _parse_int_map(s: str) -> Dict[str, int]:
    result = {}
    for item in s.split(','):
        key, val = item.split('=')
        result[key.strip()] = int(val.strip())
    return result


def main():
    args = parse_args()
    device = torch.device(f'cuda:{args.gpu}' if torch.cuda.is_available() else 'cpu')
    os.makedirs(os.path.dirname(args.out) if os.path.dirname(args.out) else '.', exist_ok=True)
    
    # Create TensorBoard writer
    import datetime
    log_dir = os.path.join(args.logdir, datetime.datetime.now().strftime('%Y%m%d-%H%M%S'))
    writer = SummaryWriter(log_dir)
    print(f"TensorBoard logs: {log_dir}")
    
    # Parse roots
    if args.roots:
        key_to_root = _parse_roots(args.roots)
    elif args.root:
        key_to_root = {'default': args.root}
    else:
        raise ValueError("Provide --root or --roots")
    
    # Parse train writers map
    if args.train_writers_map:
        train_writers_map = _parse_int_map(args.train_writers_map)
    else:
        train_writers_map = {k: args.train_writers for k in key_to_root}
    
    print(f"=" * 60)
    print(f"Signature Verification Training V3")
    print(f"=" * 60)
    print(f"TensorBoard: {log_dir}")
    print(f"=" * 60)
    
    # Log hyperparameters
    writer.add_text('Hyperparameters', f"""
    - Datasets: {list(key_to_root.keys())}
    - Train writers: {train_writers_map}
    - Pairs/epoch: {args.pairs_per_epoch}
    - Hard negative ratio: {args.hard_negative_ratio}
    - Margin: {args.margin}
    - Pos weight: {args.pos_weight}
    - Learning rate: {args.lr}
    - Batch size: {args.batch}
    - Weight decay: {args.weight_decay}
    - Warmup epochs: {args.warmup_epochs}
    - Total epochs: {args.epochs}
    - Augmentation: {not args.no_augment} ({args.augment_strength})
    """, 0)
    print(f"Train writers: {train_writers_map}")
    print(f"Device: {device}")
    print(f"Pairs/epoch: {args.pairs_per_epoch}")
    print(f"Hard negative ratio: {args.hard_negative_ratio}")
    print(f"Margin: {args.margin}, Pos weight: {args.pos_weight}")
    print(f"LR: {args.lr}, Batch: {args.batch}, Epochs: {args.epochs}")
    print(f"=" * 60)
    
    # Create dataset
    train_dataset = OnlinePairDatasetV3(
        roots=key_to_root,
        train_writers_map=train_writers_map,
        pairs_per_epoch=args.pairs_per_epoch,
        augment=not args.no_augment,
        augment_strength=args.augment_strength,
        hard_negative_ratio=args.hard_negative_ratio,
    )
    
    train_loader = DataLoader(
        train_dataset,
        batch_size=args.batch,
        shuffle=True,
        num_workers=4,
        pin_memory=True,
    )
    
    # Create model
    model = HybridEncoder(dropout=0.15).to(device)
    
    # Resume from checkpoint
    start_epoch = 0
    if args.resume and os.path.exists(args.resume):
        print(f"Resuming from {args.resume}")
        model.load_state_dict(torch.load(args.resume, map_location=device))
    
    # Enhanced loss function
    criterion = ContrastiveLoss(
        margin=args.margin,
        pos_weight=args.pos_weight,
        neg_weight=1.0,
        soft_margin=True,
    )
    
    # Optimizer with weight decay
    optimizer = torch.optim.AdamW(
        model.parameters(),
        lr=args.lr,
        weight_decay=args.weight_decay,
    )
    
    # Learning rate scheduler
    scheduler = WarmupCosineScheduler(
        optimizer,
        warmup_epochs=args.warmup_epochs,
        total_epochs=args.epochs,
        base_lr=args.lr,
    )
    
    # Training loop
    best_acc = 0.0
    best_loss = float('inf')
    patience_counter = 0
    
    for epoch in range(start_epoch, args.epochs):
        # Regenerate pairs each epoch with curriculum
        train_dataset.regenerate_pairs(epoch=epoch)
        
        model.train()
        running_loss = 0.0
        dist_genuine = []
        dist_forgery = []
        
        pbar = tqdm(train_loader, desc=f'Epoch {epoch}')
        for img1, img2, label in pbar:
            img1, img2, label = img1.to(device), img2.to(device), label.to(device)
            
            f1, f2 = model(img1), model(img2)
            dist = (f1 - f2).pow(2).sum(1).sqrt()
            loss = criterion(dist, label)
            
            optimizer.zero_grad()
            loss.backward()
            
            # Gradient clipping
            torch.nn.utils.clip_grad_norm_(model.parameters(), max_norm=1.0)
            
            optimizer.step()
            running_loss += loss.item()
            
            # Track distance distributions
            with torch.no_grad():
                gen_mask = label == 1
                forg_mask = label == 0
                if gen_mask.any():
                    dist_genuine.extend(dist[gen_mask].cpu().numpy().tolist())
                if forg_mask.any():
                    dist_forgery.extend(dist[forg_mask].cpu().numpy().tolist())
            
            pbar.set_postfix({'loss': f'{loss.item():.4f}'})
        
        # Update learning rate
        current_lr = scheduler.step()
        
        avg_loss = running_loss / len(train_loader)
        
        # Log to tensorboard
        writer.add_scalar('Train/Loss', avg_loss, epoch)
        writer.add_scalar('Train/Learning_Rate', current_lr, epoch)
        
        # Compute batch-level distance stats
        if len(dist_genuine) > 0 and len(dist_forgery) > 0:
            gen_mean, forg_mean = np.mean(dist_genuine), np.mean(dist_forgery)
            gen_std, forg_std = np.std(dist_genuine), np.std(dist_forgery)
            separation = forg_mean - gen_mean
            
            # Log distance statistics
            writer.add_scalar('Train/Distance_Genuine_Mean', gen_mean, epoch)
            writer.add_scalar('Train/Distance_Forgery_Mean', forg_mean, epoch)
            writer.add_scalar('Train/Distance_Genuine_Std', gen_std, epoch)
            writer.add_scalar('Train/Distance_Forgery_Std', forg_std, epoch)
            writer.add_scalar('Train/Distance_Separation', separation, epoch)
            writer.add_histogram('Train/Distances_Genuine', np.array(dist_genuine), epoch)
            writer.add_histogram('Train/Distances_Forgery', np.array(dist_forgery), epoch)
            
            print(f'Epoch {epoch} loss {avg_loss:.4f}  lr {current_lr:.2e}  '
                  f'dist_gen {gen_mean:.3f}  dist_forg {forg_mean:.3f}  sep {separation:.3f}')
        else:
            print(f'Epoch {epoch} loss {avg_loss:.4f}  lr {current_lr:.2e}')
        
        # Validation
        if args.val_every > 0 and ((epoch + 1) % args.val_every == 0):
            print(f'\n{"="*60}')
            print(f'Validation (epoch {epoch})')
            print(f'{"="*60}')
            
            total_acc = 0.0
            num_datasets = 0
            
            for key, root in key_to_root.items():
                tw = train_writers_map.get(key, args.train_writers)
                acc, eer = evaluate_dataset(
                    model, device, root, tw, key, args.val_max_pairs,
                    verbose=(epoch >= 20),  # Show detailed stats after epoch 20
                    writer=writer,
                    global_step=epoch,
                )
                total_acc += acc
                num_datasets += 1
            
            avg_acc = total_acc / num_datasets
            print(f'\nAverage accuracy: {avg_acc*100:.2f}%')
            
            # Log average validation accuracy
            writer.add_scalar('Validation/Average_Accuracy', avg_acc, epoch)
            
            # Save based on validation accuracy
            if avg_acc > best_acc:
                best_acc = avg_acc
                patience_counter = 0
                torch.save(model.state_dict(), args.out)
                print(f'New best accuracy {avg_acc*100:.2f}%, saving model to {args.out}')
                writer.add_scalar('Validation/Best_Accuracy', best_acc, epoch)
            else:
                patience_counter += 1
            
            writer.add_scalar('Training/Patience_Counter', patience_counter, epoch)
        
        # Early stopping
        if patience_counter >= args.patience:
            print(f'Early stopping at epoch {epoch+1} (patience={args.patience})')
            break
    
    print(f'\n{"="*60}')
    print(f'Training complete. Best model saved to {args.out}')
    print(f'Best validation accuracy: {best_acc*100:.2f}%')
    print(f'{"="*60}')
    
    # Final evaluation with best model
    print("\nFinal evaluation with best model:")
    model.load_state_dict(torch.load(args.out, map_location=device))
    for key, root in key_to_root.items():
        tw = train_writers_map.get(key, args.train_writers)
        evaluate_dataset(
            model, device, root, tw, key, args.val_max_pairs * 2,
            verbose=True, writer=writer, global_step=args.epochs
        )
    
    # Close tensorboard writer
    writer.add_text('Training/Status', f'Training completed. Best accuracy: {best_acc*100:.2f}%', args.epochs)
    writer.close()
    print(f'\nTensorBoard logs saved to: {log_dir}')
    print(f'To view: tensorboard --logdir={args.logdir}')


if __name__ == '__main__':
    main()
