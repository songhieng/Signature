#!/usr/bin/env python
"""Train writer‐ID classifier (CEDAR / MCYT). Usage:
python -m sigverify.train.train_recognition --root data/CEDAR/CEDAR --train_pct 0.25 --epochs 50 --gpu 0
"""
import os
import argparse
from math import ceil

import torch
import torch.nn as nn
from torch.utils.data import DataLoader, random_split
from torchvision import transforms
from tqdm import tqdm

from sigverify.datasets.common import WriterClassificationDataset, DEFAULT_TRANSFORM
from sigverify.models.hybrid_encoder import HybridEncoder


class ClassifierNet(nn.Module):
    def __init__(self, num_classes: int):
        super().__init__()
        # Paper: for recognition, use simplified model (reduced encoders and heads)
        self.encoder = HybridEncoder(simplified=True)
        self.fc = nn.Linear(self.encoder.output_dim, num_classes)

    def forward(self, x):
        feat = self.encoder(x)
        logits = self.fc(feat)
        return logits


def parse_args():
    ap = argparse.ArgumentParser()
    ap.add_argument('--root', required=True, help='Root directory with subfolders per writer')
    ap.add_argument('--train_pct', type=float, default=0.25, help='Fraction of images per writer used for training (0.25/0.5/0.75)')
    ap.add_argument('--batch', type=int, default=32)
    ap.add_argument('--epochs', type=int, default=50)
    ap.add_argument('--lr', type=float, default=1e-2)
    ap.add_argument('--gpu', type=int, default=0)
    ap.add_argument('--out', default='checkpoints/recognition.pt')
    return ap.parse_args()


def main():
    args = parse_args()
    device = torch.device(f'cuda:{args.gpu}' if torch.cuda.is_available() else 'cpu')
    os.makedirs(os.path.dirname(args.out), exist_ok=True)

    ds_full = WriterClassificationDataset(args.root, transform=DEFAULT_TRANSFORM)
    imgs_per_writer = {}
    for path, label in ds_full.samples:
        imgs_per_writer.setdefault(label, []).append(path)

    # create writer-wise split
    train_indices = []
    val_indices = []
    for label, paths in imgs_per_writer.items():
        n_total = len(paths)
        n_train = ceil(n_total * args.train_pct)
        label_indices = [i for i, (p, lab) in enumerate(ds_full.samples) if lab == label]
        train_indices += label_indices[:n_train]
        val_indices += label_indices[n_train:]

    train_ds = torch.utils.data.Subset(ds_full, train_indices)
    val_ds = torch.utils.data.Subset(ds_full, val_indices)

    dl_train = DataLoader(train_ds, batch_size=args.batch, shuffle=True, num_workers=4)
    dl_val = DataLoader(val_ds, batch_size=args.batch, shuffle=False, num_workers=4)

    model = ClassifierNet(num_classes=len(ds_full.class_to_idx)).to(device)
    criterion = nn.CrossEntropyLoss()
    optimizer = torch.optim.Adam(model.parameters(), lr=args.lr)
    scheduler = torch.optim.lr_scheduler.ExponentialLR(optimizer, gamma=0.95)

    best_acc = 0.0
    for epoch in range(args.epochs):
        model.train()
        total, correct, loss_sum = 0, 0, 0.0
        for imgs, labels in tqdm(dl_train, desc=f'Train {epoch}'):
            imgs, labels = imgs.to(device), labels.to(device)
            optimizer.zero_grad()
            logits = model(imgs)
            loss = criterion(logits, labels)
            loss.backward()
            optimizer.step()

            loss_sum += loss.item() * imgs.size(0)
            pred = logits.argmax(1)
            correct += (pred == labels).sum().item()
            total += imgs.size(0)
        scheduler.step()
        train_acc = correct / total * 100
        train_loss = loss_sum / total

        # validation
        model.eval()
        total, correct = 0, 0
        with torch.no_grad():
            for imgs, labels in dl_val:
                imgs, labels = imgs.to(device), labels.to(device)
                logits = model(imgs)
                pred = logits.argmax(1)
                correct += (pred == labels).sum().item()
                total += imgs.size(0)
        val_acc = correct / total * 100
        print(f'Epoch {epoch}: train loss {train_loss:.4f} acc {train_acc:.2f}%, val acc {val_acc:.2f}%')

        if val_acc > best_acc:
            best_acc = val_acc
            torch.save(model.state_dict(), args.out)
            print('Saved checkpoint')

    print('Finished. Best val acc:', best_acc)


if __name__ == '__main__':
    main()
