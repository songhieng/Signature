import os
import glob
from typing import List, Tuple, Dict
from PIL import Image
import torch
from torch.utils.data import Dataset
from torchvision import transforms


DEFAULT_TRANSFORM = transforms.Compose([
    transforms.Grayscale(),
    transforms.Resize((224, 224)),
    transforms.ToTensor(),
])


def _list_image_paths(root: str, exts=("*.png", "*.jpg", "*.jpeg", "*.tif", "*.bmp")) -> List[str]:
    paths = []
    for ext in exts:
        paths.extend(glob.glob(os.path.join(root, ext)))
    return sorted(paths)


class WriterClassificationDataset(Dataset):
    """Writer ID classification.

    root_dir should have subfolders per writer containing images.
    """

    def __init__(self, root_dir: str, transform=None):
        self.root_dir = root_dir
        self.transform = transform or DEFAULT_TRANSFORM
        self.samples: List[Tuple[str, int]] = []  # (path, label)
        self.class_to_idx: Dict[str, int] = {}
        for cls_idx, cls_name in enumerate(sorted(os.listdir(root_dir))):
            cls_path = os.path.join(root_dir, cls_name)
            if not os.path.isdir(cls_path):
                continue
            self.class_to_idx[cls_name] = cls_idx
            for img_path in _list_image_paths(cls_path):
                self.samples.append((img_path, cls_idx))

    def __len__(self):
        return len(self.samples)

    def __getitem__(self, idx):
        path, label = self.samples[idx]
        img = Image.open(path).convert("L")
        img = self.transform(img)
        return img, label


class PairSignatureDataset(Dataset):
    """Dataset returning pairs for Siamese training / evaluation.

    If `pairs` list is given it should contain tuples (path1, path2, label).
    Otherwise pairs are generated on-the-fly each epoch.
    """

    def __init__(self, root_dir: str, transform=None, pairs: List[Tuple[str, str, int]] = None):
        self.transform = transform or DEFAULT_TRANSFORM
        self.root_dir = root_dir
        self.samples_by_writer: Dict[int, List[str]] = {}
        self.all_samples: List[Tuple[str, int]] = []
        # build mapping
        writer_dirs = [d for d in os.listdir(root_dir) if os.path.isdir(os.path.join(root_dir, d))]
        for writer_idx, writer_name in enumerate(sorted(writer_dirs)):
            wpath = os.path.join(root_dir, writer_name)
            imgs = _list_image_paths(wpath)
            self.samples_by_writer[writer_idx] = imgs
            for p in imgs:
                self.all_samples.append((p, writer_idx))
        self.pairs = pairs  # optional precomputed list

    def _generate_random_pair(self):
        import random
        same = random.random() < 0.5
        if same:
            w = random.choice(list(self.samples_by_writer.keys()))
            imgs = self.samples_by_writer[w]
            p1, p2 = random.sample(imgs, 2)
            label = 1
        else:
            w1, w2 = random.sample(list(self.samples_by_writer.keys()), 2)
            p1 = random.choice(self.samples_by_writer[w1])
            p2 = random.choice(self.samples_by_writer[w2])
            label = 0
        return p1, p2, label

    def __len__(self):
        if self.pairs is not None:
            return len(self.pairs)
        return 10000  # number of on-the-fly pairs per epoch

    def __getitem__(self, idx):
        if self.pairs is not None:
            p1, p2, label = self.pairs[idx]
        else:
            p1, p2, label = self._generate_random_pair()
        img1 = Image.open(p1).convert("L")
        img2 = Image.open(p2).convert("L")
        img1 = self.transform(img1)
        img2 = self.transform(img2)
        return img1, img2, torch.tensor(label, dtype=torch.float32)
