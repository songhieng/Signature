from __future__ import annotations

import numpy as np
from PIL import Image


def to_grayscale(img: Image.Image) -> Image.Image:
    return img.convert('L')


def invert(img: Image.Image) -> Image.Image:
    arr = 255 - np.array(img, dtype=np.uint8)
    return Image.fromarray(arr, mode='L')


def median_filter(img: Image.Image, size: int = 3) -> Image.Image:
    """Lightweight denoise without cv2/skimage.

    Applies a median filter using PIL's built-in filter.
    """
    if size not in (3, 5):
        raise ValueError('median_filter size must be 3 or 5')
    from PIL import ImageFilter

    if size == 3:
        return img.filter(ImageFilter.MedianFilter(size=3))
    return img.filter(ImageFilter.MedianFilter(size=5))


def binarize_otsu(img: Image.Image) -> Image.Image:
    arr = np.array(img, dtype=np.uint8)
    hist = np.bincount(arr.flatten(), minlength=256).astype(np.float64)
    total = arr.size
    sum_total = np.dot(np.arange(256), hist)

    sum_b, w_b, w_f = 0.0, 0.0, 0.0
    var_max, threshold = -1.0, 0

    for t in range(256):
        w_b += hist[t]
        if w_b == 0:
            continue
        w_f = total - w_b
        if w_f == 0:
            break

        sum_b += t * hist[t]
        m_b = sum_b / w_b
        m_f = (sum_total - sum_b) / w_f

        var_between = w_b * w_f * (m_b - m_f) ** 2
        if var_between > var_max:
            var_max = var_between
            threshold = t

    bin_arr = (arr > threshold).astype(np.uint8) * 255
    return Image.fromarray(bin_arr, mode='L')


def crop_blank(img: Image.Image, bg_threshold: int = 250, pad: int = 5) -> Image.Image:
    arr = np.array(img, dtype=np.uint8)
    mask = arr < bg_threshold
    if not mask.any():
        return img

    ys, xs = np.where(mask)
    y0, y1 = ys.min(), ys.max()
    x0, x1 = xs.min(), xs.max()

    y0 = max(0, y0 - pad)
    x0 = max(0, x0 - pad)
    y1 = min(arr.shape[0] - 1, y1 + pad)
    x1 = min(arr.shape[1] - 1, x1 + pad)

    return img.crop((x0, y0, x1 + 1, y1 + 1))


def resize_pad(img: Image.Image, size: int = 224, fill: int = 255) -> Image.Image:
    """Resize while preserving aspect ratio, pad to square."""
    w, h = img.size
    if w == 0 or h == 0:
        return img.resize((size, size))

    scale = min(size / w, size / h)
    new_w = max(1, int(round(w * scale)))
    new_h = max(1, int(round(h * scale)))
    img_resized = img.resize((new_w, new_h), resample=Image.BILINEAR)

    canvas = Image.new('L', (size, size), color=fill)
    x0 = (size - new_w) // 2
    y0 = (size - new_h) // 2
    canvas.paste(img_resized, (x0, y0))
    return canvas


def preprocess_signature(
    img: Image.Image,
    *,
    do_invert: bool = True,
    do_denoise: bool = True,
    do_resize: bool = True,
    out_size: int = 224,
) -> Image.Image:
    """Preprocessing closer to the paper: grayscale -> crop -> denoise -> binarize -> resize -> invert."""
    img = to_grayscale(img)
    img = crop_blank(img)
    if do_denoise:
        img = median_filter(img, size=3)
    img = binarize_otsu(img)
    if do_resize:
        img = resize_pad(img, size=out_size, fill=255)
    if do_invert:
        img = invert(img)
    return img
