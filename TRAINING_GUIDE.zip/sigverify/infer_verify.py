#!/usr/bin/env python
import argparse
import os
import torch
from PIL import Image

from sigverify.datasets.common import DEFAULT_TRANSFORM
from sigverify.models.hybrid_encoder import HybridEncoder


def parse_args():
    ap = argparse.ArgumentParser()
    ap.add_argument('--ckpt', required=True, help='Path to saved .pt checkpoint')
    ap.add_argument('--ref', required=True, help='Reference (enrolled) signature image path')
    ap.add_argument('--query', required=True, help='Query signature image path')
    ap.add_argument('--thr', type=float, required=True, help='Distance threshold (use the printed Adaptive Thr)')
    ap.add_argument('--gpu', type=int, default=0)
    return ap.parse_args()


def load_model(ckpt_path: str, device: torch.device):
    model = HybridEncoder()
    state = torch.load(ckpt_path, map_location=device)
    model.load_state_dict(state)
    model.to(device)
    model.eval()
    return model


@torch.no_grad()
def embed(model: HybridEncoder, img_path: str, device: torch.device):
    img = Image.open(img_path).convert('L')
    x = DEFAULT_TRANSFORM(img).unsqueeze(0).to(device)
    feat = model(x)
    return feat


def main():
    args = parse_args()
    device = torch.device(f'cuda:{args.gpu}' if torch.cuda.is_available() else 'cpu')

    if not os.path.exists(args.ckpt):
        raise FileNotFoundError(args.ckpt)
    if not os.path.exists(args.ref):
        raise FileNotFoundError(args.ref)
    if not os.path.exists(args.query):
        raise FileNotFoundError(args.query)

    model = load_model(args.ckpt, device)
    f_ref = embed(model, args.ref, device)
    f_q = embed(model, args.query, device)

    dist = torch.norm(f_ref - f_q, p=2, dim=1).item()
    decision = 'GENUINE' if dist <= args.thr else 'FORGERY'

    print(f'distance={dist:.6f}')
    print(f'threshold={args.thr:.6f}')
    print(f'decision={decision}')


if __name__ == '__main__':
    main()
