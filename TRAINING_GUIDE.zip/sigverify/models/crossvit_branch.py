import torch
import torch.nn as nn
from .crossvit_paper import CrossViTPaper


class CrossViTBranch(nn.Module):
    """CrossViT encoder matching paper specifications.
    
    Paper configuration (for verification):
    - Small branch: patch_size=12, 1 encoder, dim=192, heads=3
    - Large branch: patch_size=16, 4 encoders, dim=384, heads=3
    - Multi-scale transformer encoders: 3
    - Cross-attention modules per multi-scale encoder: 1
    - Total output dim: 192 + 384 = 576
    
    NOTE: Paper states dim_s=128, dim_l=256, but these are not divisible by heads=3.
    Using 192/384 maintains 1:2 ratio and total 576-D output dimension.
    
    For recognition (paper states simplified model):
    - Multi-scale transformer encoders: 2 (reduced from 3)
    - Heads: 2 (reduced from 3)
    
    Input images are expected as 1-channel; they will be duplicated to 3 channels.
    """

    def __init__(
        self,
        img_size: int = 224,
        patch_size_s: int = 12,
        patch_size_l: int = 16,
        dim_s: int = 192,
        dim_l: int = 384,
        heads: int = 3,
        num_encoders_s: int = 1,
        num_encoders_l: int = 4,
        num_multi_scale: int = 3,
        num_ca_per_ms: int = 1,
        out_dim: int | None = None,
        simplified: bool = False,  # Set True for recognition task
    ):
        super().__init__()
        
        # Paper: for recognition, reduce multi-scale encoders to 2 and heads to 2
        if simplified:
            num_multi_scale = 2
            heads = 2
        
        self.backbone = CrossViTPaper(
            img_size=img_size,
            in_channels=3,
            patch_size_s=patch_size_s,
            patch_size_l=patch_size_l,
            dim_s=dim_s,
            dim_l=dim_l,
            heads=heads,
            num_encoders_s=num_encoders_s,
            num_encoders_l=num_encoders_l,
            num_multi_scale=num_multi_scale,
            num_ca_per_ms=num_ca_per_ms,
        )
        
        in_features = self.backbone.num_features  # dim_s + dim_l = 576
        if out_dim is None:
            out_dim = in_features
        
        self.fc = nn.Identity() if in_features == out_dim else nn.Linear(in_features, out_dim)
        self.out_dim = out_dim

    def forward(self, x):  # x (B,1,224,224)
        if x.shape[1] == 1:
            x = x.repeat(1, 3, 1, 1)
        feats = self.backbone(x)  # (B, dim_s + dim_l = 576)
        feats = self.fc(feats)
        return feats
