"""
CrossViT implementation matching the paper specifications:
- Small branch: patch_size=12, num_encoders=1, dim=192, heads=3
- Large branch: patch_size=16, num_encoders=4, dim=384, heads=3
- Multi-scale transformer encoders: 3
- Cross-attention modules per multi-scale encoder: 1

NOTE: Paper states dim_s=128, dim_l=256, but these are not divisible by heads=3.
Using dim_s=192 (192/3=64) and dim_l=384 (384/3=128) for valid multi-head attention.
This maintains the 1:2 ratio and total output dimension of 576.
"""

import torch
import torch.nn as nn
import torch.nn.functional as F
from einops import rearrange
from einops.layers.torch import Rearrange


class PatchEmbedding(nn.Module):
    """Convert image to patch embeddings using convolution."""
    
    def __init__(self, in_channels=3, patch_size=16, embed_dim=256):
        super().__init__()
        self.patch_size = patch_size
        self.proj = nn.Conv2d(in_channels, embed_dim, kernel_size=patch_size, stride=patch_size)
        
    def forward(self, x):
        # x: (B, C, H, W)
        x = self.proj(x)  # (B, embed_dim, H/patch_size, W/patch_size)
        x = rearrange(x, 'b c h w -> b (h w) c')  # (B, num_patches, embed_dim)
        return x


class MultiHeadSelfAttention(nn.Module):
    """Multi-head self-attention mechanism."""
    
    def __init__(self, dim, heads=3):
        super().__init__()
        self.heads = heads
        self.scale = (dim // heads) ** -0.5
        
        self.qkv = nn.Linear(dim, dim * 3, bias=False)
        self.proj = nn.Linear(dim, dim)
        
    def forward(self, x):
        B, N, C = x.shape
        qkv = self.qkv(x).reshape(B, N, 3, self.heads, C // self.heads).permute(2, 0, 3, 1, 4)
        q, k, v = qkv[0], qkv[1], qkv[2]  # (B, heads, N, C//heads)
        
        attn = (q @ k.transpose(-2, -1)) * self.scale  # (B, heads, N, N)
        attn = attn.softmax(dim=-1)
        
        x = (attn @ v).transpose(1, 2).reshape(B, N, C)  # (B, N, C)
        x = self.proj(x)
        return x


class FeedForward(nn.Module):
    """Feed-forward network with GELU activation."""
    
    def __init__(self, dim, hidden_dim=None, dropout=0.):
        super().__init__()
        hidden_dim = hidden_dim or 4 * dim
        self.net = nn.Sequential(
            nn.Linear(dim, hidden_dim),
            nn.GELU(),
            nn.Dropout(dropout),
            nn.Linear(hidden_dim, dim),
            nn.Dropout(dropout)
        )
        
    def forward(self, x):
        return self.net(x)


class TransformerEncoder(nn.Module):
    """Standard Transformer encoder block."""
    
    def __init__(self, dim, heads=3, mlp_ratio=4., dropout=0.):
        super().__init__()
        self.norm1 = nn.LayerNorm(dim)
        self.attn = MultiHeadSelfAttention(dim, heads)
        self.norm2 = nn.LayerNorm(dim)
        self.mlp = FeedForward(dim, int(dim * mlp_ratio), dropout)
        
    def forward(self, x):
        x = x + self.attn(self.norm1(x))
        x = x + self.mlp(self.norm2(x))
        return x


class CrossAttention(nn.Module):
    """Cross-attention module between two branches as described in paper (Equations 1-3, Figure 4).
    
    Paper formula:
    x'_s = [f_s(x^s_cls) || x^l_patch]  (Eq. 1)
    q = x'^s_cls * W_q, k = x'_s * W_k, v = x'_s * W_v  (Eq. 2)
    A = softmax(qk^T / sqrt(C/h)), CA(x'_s) = Av  (Eq. 3)
    """
    
    def __init__(self, dim_q, dim_kv, heads=3):
        super().__init__()
        self.heads = heads
        self.dim_q = dim_q
        self.scale = (dim_q // heads) ** -0.5
        
        # f() projection to align CLS token dimension to kv dimension for concatenation
        self.proj_cls = nn.Linear(dim_q, dim_kv, bias=False) if dim_q != dim_kv else nn.Identity()
        
        # After concatenation, we have [projected_cls || other_patch] all in dim_kv
        # Query comes from projected CLS (dim_kv), K/V from the concatenated sequence (dim_kv)
        self.to_q = nn.Linear(dim_kv, dim_q, bias=False)
        self.to_k = nn.Linear(dim_kv, dim_q, bias=False)
        self.to_v = nn.Linear(dim_kv, dim_q, bias=False)
        self.proj = nn.Linear(dim_q, dim_q)
        
    def forward(self, x_cls, x_patch_other):
        """
        Paper implementation of Equations 1-3:
        x_cls: CLS token from this branch (B, 1, dim_q)
        x_patch_other: patch tokens from OTHER branch (B, N, dim_kv)
        Returns: updated CLS token (B, 1, dim_q)
        """
        B, _, C = x_cls.shape
        
        # Eq. 1: x'_s = [f_s(x^s_cls) || x^l_patch]
        cls_projected = self.proj_cls(x_cls)  # (B, 1, dim_kv)
        x_concat = torch.cat([cls_projected, x_patch_other], dim=1)  # (B, 1+N, dim_kv)
        
        # Eq. 2: Query from projected CLS only, K/V from full concatenated sequence
        q = self.to_q(cls_projected).reshape(B, 1, self.heads, C // self.heads).permute(0, 2, 1, 3)
        k = self.to_k(x_concat).reshape(B, -1, self.heads, C // self.heads).permute(0, 2, 1, 3)
        v = self.to_v(x_concat).reshape(B, -1, self.heads, C // self.heads).permute(0, 2, 1, 3)
        
        # Eq. 3: Attention
        attn = (q @ k.transpose(-2, -1)) * self.scale
        attn = attn.softmax(dim=-1)
        
        out = (attn @ v).transpose(1, 2).reshape(B, 1, C)
        out = self.proj(out)
        return out


class CrossAttentionModule(nn.Module):
    """Token fusion module using cross-attention (paper Figure 4)."""
    
    def __init__(self, dim_s, dim_l, heads=3):
        super().__init__()
        # Small branch queries large branch
        self.ca_s = CrossAttention(dim_s, dim_l, heads)
        # Large branch queries small branch
        self.ca_l = CrossAttention(dim_l, dim_s, heads)
        self.norm_s = nn.LayerNorm(dim_s)
        self.norm_l = nn.LayerNorm(dim_l)
        
    def forward(self, xs_cls, xs_patch, xl_cls, xl_patch):
        """
        xs_cls: small branch CLS token
        xs_patch: small branch patch tokens
        xl_cls: large branch CLS token
        xl_patch: large branch patch tokens
        """
        # Small branch CLS attends to large branch patches
        xs_cls_new = xs_cls + self.ca_s(self.norm_s(xs_cls), xl_patch)
        
        # Large branch CLS attends to small branch patches
        xl_cls_new = xl_cls + self.ca_l(self.norm_l(xl_cls), xs_patch)
        
        return xs_cls_new, xl_cls_new


class MultiScaleTransformerEncoder(nn.Module):
    """Multi-scale transformer encoder with cross-attention."""
    
    def __init__(self, dim_s, dim_l, heads=3, num_ca=1):
        super().__init__()
        self.encoder_s = TransformerEncoder(dim_s, heads)
        self.encoder_l = TransformerEncoder(dim_l, heads)
        self.cross_attn_modules = nn.ModuleList([
            CrossAttentionModule(dim_s, dim_l, heads) for _ in range(num_ca)
        ])
        
    def forward(self, xs_cls, xs_patch, xl_cls, xl_patch):
        # Process through standard encoders
        xs = torch.cat([xs_cls, xs_patch], dim=1)
        xl = torch.cat([xl_cls, xl_patch], dim=1)
        
        xs = self.encoder_s(xs)
        xl = self.encoder_l(xl)
        
        xs_cls, xs_patch = xs[:, :1], xs[:, 1:]
        xl_cls, xl_patch = xl[:, :1], xl[:, 1:]
        
        # Cross-attention between branches
        for ca_module in self.cross_attn_modules:
            xs_cls, xl_cls = ca_module(xs_cls, xs_patch, xl_cls, xl_patch)
            
        return xs_cls, xs_patch, xl_cls, xl_patch


class CrossViTPaper(nn.Module):
    """
    CrossViT as specified in the paper:
    - Small branch: patch_size=12, 1 encoder, dim=192, heads=3
    - Large branch: patch_size=16, 4 encoders, dim=384, heads=3
    - 3 multi-scale transformer encoders
    - 1 cross-attention module per multi-scale encoder
    
    Note: For patch_size=12 with img_size=224, we use img_size=240 internally
    (resize input) to ensure clean division: 240/12=20, 240/16=15.
    
    Paper states dim_s=128, dim_l=256, but these are not divisible by heads=3,
    which breaks multi-head attention. Using 192/384 maintains 1:2 ratio and
    total 576-D output (matching paper's reported feature dimension).
    """
    
    def __init__(
        self,
        img_size=224,
        in_channels=3,
        patch_size_s=12,
        patch_size_l=16,
        dim_s=192,
        dim_l=384,
        heads=3,
        num_encoders_s=1,
        num_encoders_l=4,
        num_multi_scale=3,
        num_ca_per_ms=1,
    ):
        super().__init__()
        
        # Adjust image size to be divisible by both patch sizes
        # Paper uses 12 and 16; LCM(12,16)=48. Nearest to 224 divisible by 48 is 240.
        self.internal_size = 240  # 240/12=20, 240/16=15
        self.input_size = img_size
        
        # Patch embeddings
        self.patch_embed_s = PatchEmbedding(in_channels, patch_size_s, dim_s)
        self.patch_embed_l = PatchEmbedding(in_channels, patch_size_l, dim_l)
        
        # CLS tokens
        self.cls_token_s = nn.Parameter(torch.randn(1, 1, dim_s))
        self.cls_token_l = nn.Parameter(torch.randn(1, 1, dim_l))
        
        # Positional embeddings (computed for internal size)
        num_patches_s = (self.internal_size // patch_size_s) ** 2  # 20*20=400
        num_patches_l = (self.internal_size // patch_size_l) ** 2  # 15*15=225
        self.pos_embed_s = nn.Parameter(torch.randn(1, num_patches_s + 1, dim_s))
        self.pos_embed_l = nn.Parameter(torch.randn(1, num_patches_l + 1, dim_l))
        
        # Small branch encoders
        self.encoders_s = nn.ModuleList([
            TransformerEncoder(dim_s, heads) for _ in range(num_encoders_s)
        ])
        
        # Large branch encoders
        self.encoders_l = nn.ModuleList([
            TransformerEncoder(dim_l, heads) for _ in range(num_encoders_l)
        ])
        
        # Multi-scale transformer encoders
        self.multi_scale_encoders = nn.ModuleList([
            MultiScaleTransformerEncoder(dim_s, dim_l, heads, num_ca_per_ms)
            for _ in range(num_multi_scale)
        ])
        
        # Output dimensions
        self.dim_s = dim_s
        self.dim_l = dim_l
        self.num_features = dim_s + dim_l
        
    def forward(self, x):
        B = x.shape[0]
        
        # Resize to internal size for clean patch division
        if x.shape[-1] != self.internal_size or x.shape[-2] != self.internal_size:
            x = F.interpolate(x, size=(self.internal_size, self.internal_size), mode='bilinear', align_corners=False)
        
        # Patch embeddings
        xs_patch = self.patch_embed_s(x)  # (B, Ns, dim_s)
        xl_patch = self.patch_embed_l(x)  # (B, Nl, dim_l)
        
        # Add CLS tokens
        xs_cls = self.cls_token_s.expand(B, -1, -1)
        xl_cls = self.cls_token_l.expand(B, -1, -1)
        
        # Add positional embeddings
        xs = torch.cat([xs_cls, xs_patch], dim=1) + self.pos_embed_s
        xl = torch.cat([xl_cls, xl_patch], dim=1) + self.pos_embed_l
        
        # Separate CLS and patches after adding pos embeddings
        xs_cls, xs_patch = xs[:, :1], xs[:, 1:]
        xl_cls, xl_patch = xl[:, :1], xl[:, 1:]
        
        # Process through branch-specific encoders
        for encoder in self.encoders_s:
            xs = torch.cat([xs_cls, xs_patch], dim=1)
            xs = encoder(xs)
            xs_cls, xs_patch = xs[:, :1], xs[:, 1:]
            
        for encoder in self.encoders_l:
            xl = torch.cat([xl_cls, xl_patch], dim=1)
            xl = encoder(xl)
            xl_cls, xl_patch = xl[:, :1], xl[:, 1:]
        
        # Process through multi-scale encoders with cross-attention
        for ms_encoder in self.multi_scale_encoders:
            xs_cls, xs_patch, xl_cls, xl_patch = ms_encoder(
                xs_cls, xs_patch, xl_cls, xl_patch
            )
        
        # Concatenate CLS tokens from both branches
        feat = torch.cat([xs_cls.squeeze(1), xl_cls.squeeze(1)], dim=1)  # (B, dim_s + dim_l)
        return feat
