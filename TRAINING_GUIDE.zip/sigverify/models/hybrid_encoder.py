import torch
import torch.nn as nn

from .cnn_branch import CNNBranch
from .crossvit_branch import CrossViTBranch


class HybridEncoder(nn.Module):
    """CNN + CrossViT encoder matching paper specifications.
    
    Paper configuration:
    - CNN (FPN-style pooled stages): 192 (=3*64)
    - CrossViT (dual-branch transformer): 576 (192 + 384)
    - Total: 768
    
    NOTE: Paper reports 576-D total but the math shows 768-D (192 CNN + 576 CrossViT).
    The dimensions used here match multi-head attention constraints (divisible by heads).
    
    For recognition task, set simplified=True to use:
    - Reduced multi-scale encoders (2 instead of 3)
    - Reduced heads (2 instead of 3)
    """

    def __init__(
        self,
        cnn_fp_dim: int = 64,
        vit_dim_s: int = 192,
        vit_dim_l: int = 384,
        use_projection: bool = True,  # Default True to match paper's 576-D
        proj_dim: int = 576,
        simplified: bool = False,  # Set True for recognition task
        dropout: float = 0.1,  # Dropout for regularization
    ):
        super().__init__()
        self.cnn = CNNBranch(fp_dim=cnn_fp_dim)
        
        # CrossViT with corrected dims: outputs 576-D (192 + 384)
        vit_out_dim = vit_dim_s + vit_dim_l
        self.vit = CrossViTBranch(
            dim_s=vit_dim_s,
            dim_l=vit_dim_l,
            out_dim=vit_out_dim,  # 576-D output
            simplified=simplified,
        )
        
        total_dim = self.cnn.out_dim + vit_out_dim  # 192 + 576 = 768
        
        # Dropout for regularization
        self.dropout = nn.Dropout(p=dropout)
        
        # Always project to 576-D to match paper (unless explicitly disabled)
        if use_projection:
            self.proj = nn.Linear(total_dim, proj_dim)
            self.output_dim = proj_dim
        else:
            self.proj = None
            self.output_dim = total_dim
        
        print(f'[HybridEncoder] CNN dim: {self.cnn.out_dim}, ViT dim: {vit_out_dim}, Concat: {total_dim}, Final: {self.output_dim}, Simplified: {simplified}')

    def forward(self, x):  # (B,1,224,224)
        cnn_f = self.cnn(x)  # (B, 192)
        vit_f = self.vit(x)  # (B, 576)
        
        # Concatenate features from both branches
        feat = torch.cat([cnn_f, vit_f], dim=1)  # (B, 768)
        
        # Apply dropout before projection
        feat = self.dropout(feat)
        
        if self.proj is not None:
            feat = self.proj(feat)
            
        # L2 normalization on final feature (standard for metric learning)
        feat = torch.nn.functional.normalize(feat, p=2, dim=1)
        return feat
