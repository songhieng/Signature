import torch
import torch.nn as nn
import torch.nn.functional as F
from torchvision import models


class CNNBranch(nn.Module):
    """ResNet-18 backbone with a lightweight feature-pyramid embedding.

    Produces a fixed vector by pooling 3 ResNet stages and concatenating them.

    Levels used (ResNet-18):
    - c2: layer1 output (spatial ~56x56)
    - c3: layer2 output (spatial ~28x28)
    - c4: layer3 output (spatial ~14x14)

    Each level is projected to `fp_dim` via 1x1 conv and global-average pooled.
    Final embedding dim = 3 * fp_dim.
    """

    def __init__(self, fp_dim: int = 64):
        super().__init__()
        self.fp_dim = fp_dim

        resnet = models.resnet18(weights=None)
        resnet.conv1 = nn.Conv2d(1, 64, kernel_size=7, stride=2, padding=3, bias=False)

        # Stem
        self.conv1 = resnet.conv1
        self.bn1 = resnet.bn1
        self.relu = resnet.relu
        self.maxpool = resnet.maxpool

        # Stages
        self.layer1 = resnet.layer1  # 64
        self.layer2 = resnet.layer2  # 128
        self.layer3 = resnet.layer3  # 256

        # Lateral projections
        self.lat2 = nn.Conv2d(64, fp_dim, kernel_size=1, bias=False)
        self.lat3 = nn.Conv2d(128, fp_dim, kernel_size=1, bias=False)
        self.lat4 = nn.Conv2d(256, fp_dim, kernel_size=1, bias=False)

        self.gap = nn.AdaptiveAvgPool2d((1, 1))

    @property
    def out_dim(self) -> int:
        return 3 * self.fp_dim

    def forward(self, x):  # x: (B,1,224,224)
        x = self.relu(self.bn1(self.conv1(x)))
        x = self.maxpool(x)

        c2 = self.layer1(x)
        c3 = self.layer2(c2)
        c4 = self.layer3(c3)

        p2 = self.lat2(c2)
        p3 = self.lat3(c3)
        p4 = self.lat4(c4)

        f2 = self.gap(p2).flatten(1)
        f3 = self.gap(p3).flatten(1)
        f4 = self.gap(p4).flatten(1)

        return torch.cat([f2, f3, f4], dim=1)
