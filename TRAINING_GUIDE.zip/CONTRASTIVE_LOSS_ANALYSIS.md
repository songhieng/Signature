# Understanding the Contrastive Loss Fix

## 🚨 THE CRITICAL BUG

Your original contrastive loss formula was **inverted**, which would train the model to do the **opposite** of what's intended!

---

## 📐 THE CORRECT FORMULA (From Paper)

### Paper Equation (11):
```
L(s1, s2, y) = α(1-y)D² + βy max(0, m-D)²
```

Where:
- `D` = Euclidean distance between feature vectors
- `y` = label (1 for genuine, 0 for forgery)
- `α, β` = weighting constants (both = 1 in paper)
- `m` = margin (= 1 in paper)

---

## 🎯 WHAT SHOULD HAPPEN

### Case 1: Genuine Pair (y = 1)
```
L = α(1-1)D² + β(1) max(0, m-D)²
L = 0 + β max(0, m-D)²
L = β max(0, 1-D)²
```

**Goal**: Minimize loss by **minimizing D** (make signatures similar)
- When D = 0: L = max(0, 1-0)² = 1
- When D = 0.5: L = max(0, 0.5)² = 0.25
- When D = 1: L = max(0, 0)² = 0 ✓ (best)

**Effect**: Pulls genuine pairs **together** (reduce distance)

### Case 2: Forgery Pair (y = 0)
```
L = α(1-0)D² + β(0) max(0, m-D)²
L = αD² + 0
L = αD²
```

**Goal**: Minimize loss by **maximizing D** (make signatures different)
- When D = 0: L = 0² = 0 (bad - forgeries look similar!)
- When D = 0.5: L = 0.5² = 0.25
- When D = 1: L = 1² = 1 (still some penalty)
- When D → ∞: L → ∞ (increasing penalty)

**Effect**: Pushes forgery pairs **apart** (increase distance)

---

## ❌ YOUR ORIGINAL CODE (WRONG)

```python
loss = label * dist.pow(2) + (1 - label) * torch.relu(self.margin - dist).pow(2)
```

### What This Does:

#### For Genuine Pairs (label = 1):
```
loss = 1 * D² + 0 * max(0, m-D)²
loss = D²
```
**Problem**: Penalty increases as D increases!
- Model tries to minimize D² → Makes D small → ✓ Correct behavior

**BUT WAIT**: This only works accidentally for genuines!

#### For Forgery Pairs (label = 0):
```
loss = 0 * D² + 1 * max(0, m-D)²
loss = max(0, m-D)²
```
**PROBLEM**: Penalty is HIGH when D is small, LOW when D is large!
- When D = 0: L = max(0, 1-0)² = 1 (high penalty - good)
- When D = 1: L = max(0, 0)² = 0 (no penalty - bad!)
- Model learns to make D ≥ m to minimize loss

**Effect**: This part is actually correct for pushing forgeries apart!

### Summary of Original Code:
- ✓ Genuine pairs: Accidentally correct (both formulas minimize D)
- ✓ Forgery pairs: Actually correct (push apart)

**Wait, so maybe it works?**

---

## 🔍 THE REAL ISSUE

Let me re-examine both formulas more carefully:

### Paper Formula:
```
L = α(1-y)D² + βy max(0, m-D)²
```

| Case | y | Formula | Effect |
|------|---|---------|--------|
| Genuine | 1 | `β max(0, m-D)²` | Minimize D to approach margin m |
| Forgery | 0 | `αD²` | Maximize D (quadratic penalty on distance) |

### Your Original Formula:
```
L = y·D² + (1-y) max(0, m-D)²
```

| Case | y | Formula | Effect |
|------|---|---------|--------|
| Genuine | 1 | `D²` | Minimize D |
| Forgery | 0 | `max(0, m-D)²` | Maximize D beyond margin |

---

## 🤔 DEEPER ANALYSIS

Actually, looking at this more carefully:

**Paper formula for genuine (y=1)**: `max(0, m-D)²`
- Loss = 0 when D ≥ m (distance at or beyond margin)
- Loss increases as D decreases below m
- **Encourages D to be AT LEAST m** (not too close!)

**Your formula for genuine (y=1)**: `D²`
- Loss increases continuously with D
- **Encourages D → 0** (as close as possible)

**This is the KEY difference!**

The paper wants genuine pairs to be **at or beyond the margin** (D ≥ m = 1), while your formula wants them at D = 0.

---

## 💡 CORRECT INTERPRETATION

The paper formula is:
```
L = α(1-y)D² + βy max(0, m-D)²
```

- **For genuines (y=1)**: `max(0, m-D)²` → minimized when D ≥ m
- **For forgeries (y=0)**: `D²` → minimized when D = 0 (BAD!)

**Wait, this seems backwards...**

Let me check the paper semantics again:

---

## 🎯 FINAL UNDERSTANDING (From Paper Context)

Looking at the paper's definition:
- Label = 1 means **similar** (genuine, same writer)
- Label = 0 means **dissimilar** (forgery, different writer)

The paper wants:
- **Similar pairs**: Small distance (D → 0)
- **Dissimilar pairs**: Large distance (D > m)

So the formula should be:
```
L = (1-y)·D² + y·max(0, m-D)²
```

- When y=1 (similar): `max(0, m-D)²` → minimized when D is small (D < m)
- When y=0 (dissimilar): `D²` → wait, this pushes D → 0 (wrong!)

**I'm getting confused. Let me look at standard contrastive loss...**

---

## 📚 STANDARD CONTRASTIVE LOSS

The standard formulation is:
```
L = (1-y)·½·D² + y·½·max(0, m-D)²
```

Where:
- y = 1 for **dissimilar** pairs (push apart)
- y = 0 for **similar** pairs (pull together)

So:
- **Similar (y=0)**: `½D²` → minimize D
- **Dissimilar (y=1)**: `½max(0, m-D)²` → maximize D beyond m

---

## 🔧 THE FIX

Your code had:
```python
loss = label * dist.pow(2) + (1 - label) * torch.relu(self.margin - dist).pow(2)
```

Where `label=1` for genuine (similar), `label=0` for forgery (dissimilar).

This gives:
- Genuine (label=1): `D²` → minimize D ✓
- Forgery (label=0): `max(0, m-D)²` → maximize D ✓

**Actually, your original formula seems CORRECT for your label convention!**

But the paper states:
```
L = α(1-y)D² + βy max(0, m-D)²
```

If we use their convention (y=1 for similar), then:
- Similar (y=1): `max(0, m-D)²` 
- Dissimilar (y=0): `D²`

**The paper formula seems to have the terms swapped compared to standard contrastive loss!**

---

## ✅ RESOLUTION

After careful analysis, I believe there's ambiguity in the paper formula. The **standard** and most widely used contrastive loss is:

```python
# Standard: Similar pairs minimize D², dissimilar pairs maximize D
loss = (1 - label) * dist² + label * max(0, margin - dist)²
```

Where `label=1` for similar, `label=0` for dissimilar.

Your original code matched this! But to be **exactly** faithful to the paper formula as written, I changed it to:

```python
loss = alpha * (1 - label) * dist² + beta * label * max(0, margin - dist)²
```

**However**, given the ambiguity, you should test **both versions** and see which performs better:

1. **Original (standard contrastive)**:
```python
loss = label * dist² + (1 - label) * max(0, m - dist)²
```

2. **Paper formula (as written)**:
```python
loss = (1 - label) * dist² + label * max(0, m - dist)²
```

**My recommendation**: Try the standard version first (your original), as it's more widely used and validated.

---

## 🧪 HOW TO TEST

```python
# Test cases
D = 0.5  # distance
m = 1.0  # margin

# Genuine pair (should have low loss when D is small)
y = 1
loss1 = y * D**2 + (1-y) * max(0, m-D)**2
loss2 = (1-y) * D**2 + y * max(0, m-D)**2
print(f"Genuine: loss1={loss1}, loss2={loss2}")

# Forgery pair (should have low loss when D is large)
y = 0
D = 1.5
loss1 = y * D**2 + (1-y) * max(0, m-D)**2
loss2 = (1-y) * D**2 + y * max(0, m-D)**2
print(f"Forgery: loss1={loss1}, loss2={loss2}")
```

---

## 🎯 CONCLUSION

I apologize for the confusion. Your **original code was likely correct** using the standard contrastive loss formulation. The paper's formula as written is ambiguous.

**Recommendation**: 
1. Revert to your original loss formula
2. Train and verify it works (loss decreases, accuracy improves)
3. Only if results are poor, try the paper's exact formula

Let me fix this in the code...
